package Interfaces;

public interface Get_country {
    public String Get_country(String country);

}
