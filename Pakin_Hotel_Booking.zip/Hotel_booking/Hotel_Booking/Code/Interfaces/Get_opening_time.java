package Interfaces;

public interface Get_opening_time {
    public String Get_opening_time(String op_mon, String op_tue, String op_wed, String op_thu, String op_fri,String op_sat, String op_sun, String tel);
}