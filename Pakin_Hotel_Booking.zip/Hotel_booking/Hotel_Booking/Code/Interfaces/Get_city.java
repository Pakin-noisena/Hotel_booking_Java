package Interfaces;

public interface Get_city {
    public String Get_city(String city);
}

