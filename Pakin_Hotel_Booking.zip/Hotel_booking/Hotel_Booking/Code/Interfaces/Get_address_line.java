package Interfaces;

public interface Get_address_line {
    //public void Address_line(String address_line1,String address_line2);
    public String Get_address_line(String address_line1);

}
