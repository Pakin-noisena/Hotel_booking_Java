package Payment;

public class Card extends Invoices { // Subclass Card (Invoice)
    private String nameoncard,visa,credit;
    private int numberoncard, CW;

    public Card(double room_price, double service_fee, String status,Receipts rec, String visa, String credit, String nameoncard,
                int numberoncard, int CW){
        super(room_price,service_fee,status,rec);
        this.visa = visa;
        this.credit = credit;
        this.nameoncard = nameoncard;
        this.numberoncard = numberoncard;
        this.CW = CW;
    }

    //get
    public String getVisa(){
        return this.visa;
    }

    public String getCredit(){
        return this.credit;
    }

    public String getNameoncard(){
        return this.nameoncard;
    }

    public int getNumberoncard(){
        return this.numberoncard;
    }

    //set
    public void setVisa(String visa){
        this.visa = visa;
    }

    public void setCredit(String credit){
        this.credit = credit;
    }

    public void setNameoncard(String nameoncard){
        this.nameoncard = nameoncard;
    }

    public void setNumberoncard(int numberoncard){
        this.numberoncard = numberoncard;
    }

    public void setCW(int CW){
        this.CW = CW;
    }

    // String
    public String toString(){
        String str;
        str = "Card:\n" +  super.toString() + "\nVisa: " + this.visa + "\nCredit: " + this.credit + "\nName on card: " +
                this.nameoncard + "\nNumber on card: " + this.numberoncard + "\nCW: " + this.CW;
        return str;
    }
}

