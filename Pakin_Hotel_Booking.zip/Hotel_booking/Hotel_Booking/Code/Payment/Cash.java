package Payment;


public class Cash extends Invoices { // Subclass Cash (Invoice)
    private String currency;
    public Cash(double room_price, double service_fee, String status,Receipts rec,String currency){
        super(room_price,service_fee,status, rec);
        this.currency = currency;
    }

    //get
    public String getCurrency(){
        return this.currency;
    }

    //set
    public void setCurrency(String currency){
        this.currency = currency;
    }


    public String toString(){
        String str;
        str = "Cash:\n" + super.toString() + "\nCurrency: " + this.currency + "\n";
        return str;
    }
}
