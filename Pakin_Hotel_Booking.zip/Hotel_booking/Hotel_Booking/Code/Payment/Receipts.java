package Payment;

import java.text.Format;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
public class Receipts { // composite class
    protected String hotel_name, user_name,description;
    protected int invoice_no, quantity;
    protected double amount, total;
    protected String date;

    // default
    public Receipts(){
        this.hotel_name = "default";
        this.user_name = "default";
        this.invoice_no = 0;
        this.description = "default";
        this.date = date;
        this.quantity = 0;
        this.amount = 0.0;
        this.total = 0.0;
    }

    //value
    public Receipts(String hotel_name,String user_name,String description,int invoice_no,
                    int quantity,double amount,double total,String date){
        this.hotel_name = hotel_name;
        this.user_name = user_name;
        this.date = date;
        this.description = description;
        this.invoice_no = invoice_no;
        this.quantity = quantity;
        this.amount = amount;
        this.total = total;
    }

    //get
    public String getHotel_name(){
        return this.hotel_name;
    }

    public String getUser_name(){
        return this.user_name;
    }

    public String getDescription(){
        return this.description;
    }

    public String date(){
        return this.date;
    }

    public int getInvoice_no(){
        return this.invoice_no;
    }

    public int getQuantity(){
        return this.quantity;
    }

    public double getAmount(){
        return this.amount;
    }

    public double getTotal(){
        return this.total;
    }

    //set
    public void setHotel_name(String hotel_name){
        this.hotel_name = hotel_name;
    }

    public void setUser_name(String user_name){
        this.user_name = user_name;
    }

    public void setDescription(String description){
        this.description = description;
    }

    public void setDate (String date) {
        this.date = date;
    }

    public void setInvoice_no(int invoice_no){
        this.invoice_no = invoice_no;
    }

    public void setQuantity(int quantity){
        this.quantity = quantity;
    }

    public void setAmout(double amount){
        this.amount = amount;
    }

    public void setTotal(double total){
        this.total = total;
    }

    //String
    public String toString(){
        return "Receipt: " + "\n\tInvoice no.: " + this.invoice_no  + "\n\tHotel name: " + this.hotel_name + "\n\tUser name: " +this.user_name +
                  "\n\tDate: " + this.date + "\n\tDescription: " + this.description +
                 "\n\tQuantity: " + this.quantity + "\n\tAmount: " + this.amount +
                "bath\n\tTotal: " + this.total + "bath\n";
    }
}
