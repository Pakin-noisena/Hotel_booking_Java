package Payment;

import java.text.*;
import java.util.*;

public class Invoices {
    protected double  service_fee, room_price;
    protected String status;
    protected Receipts rec;

    public Invoices(double room_price, double service_fee, String status,Receipts rec) {
        this.room_price = room_price;
        this.service_fee = service_fee;
        this.status = status;
        this.rec = rec;
    }
    // for using bookdate and amount funtion
    public Invoices(double room_price, double service_fee){
        this.room_price = room_price;
        this.service_fee = service_fee;
        this.status = "Yes";
        this.rec = new Receipts();
    }

    public String toString(){
        return "Invoice: " + "\n\tRoom Price: " + this.room_price + "bath\n\tService fee : " + (service_fee*room_price) +
                "bath\n\tStatus : " + this.status + "\nReceipt: " + "\n\tUser name: " + this.rec.user_name + "\n\tHotel name: " + this.rec.hotel_name + "\n\tDate: " + this.rec.date +
                 "\n\tDescription: " + this.rec.description +
                "\n\tInvoice no.: " + this.rec.invoice_no + "\n\tQuantity: " + this.rec.quantity +
                "\n\tAmount: " + this.rec.amount + "\n\tTotal: " + this.rec.total;
    }

    // Local Date
    public String Booking_Date(){
        Format formatter;
        formatter = new SimpleDateFormat("dd/MM/YYYY", new Locale("en", "EN"));
        return formatter.format(new Date());
    }

    // sum all to find final amount
    public double Amount(){
        double A1 = Double.sum(room_price, room_price*service_fee);
        return A1;
    }

    //get
    public double getroom_price(){
        return this.room_price;
    }

    public double getService_fee(){
        return this.service_fee;
    }

    public String getstatus(){
        return this.status;
    }

    public Receipts getRec(){
        return this.rec;
    }

    //set
    public void setroom_price(Double room_price) {
        this.room_price = room_price;
    }

    public void setservice_fee(Double service_fee) {
        this.service_fee = service_fee;
    }

    public void setStatus(String status){
        this.status = status;
    }

    public void setRec(Receipts rec){
        this.rec = rec;
    }

}
