package Payment;


public class Online_banking extends Invoices { // Subclass online banking (Invoice)
    private String bank_name;
    private int ref_no;
    public Online_banking(double room_price, double service_fee, String status,Receipts rec,
                          String bank_name, int ref_no){
        super(room_price,service_fee,status, rec);
        this.bank_name = bank_name;
        this.ref_no = ref_no;
    }

    //get
    public String getBank_name() {
        return this.bank_name;
    }

    public int getRef_no(){
        return  this.ref_no;
    }

    //set
    public void setBank_name(String bank_name){
        this.bank_name = bank_name;
    }

    public void setRef_no(int ref_no){
        this.ref_no = ref_no;
    }

    //toString
    public String toString(){
        String str;
        str = "Online Banking:\n" + super.toString() + "\nBank name: " + this.bank_name + "\nRef.no: " + this.ref_no;
        return str;
    }
}
