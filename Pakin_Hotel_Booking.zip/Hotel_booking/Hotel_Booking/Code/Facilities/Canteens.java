package Facilities;
import Interfaces.Get_opening_time;

public class Canteens implements Get_opening_time {
    public double price_per_person;

    //default
    public Canteens(){
        this.price_per_person = 0.0;
    }

    //value
    public Canteens(double price_per_person){
        this.price_per_person = price_per_person;
    }

    //get
    public double getPrice_per_person(){
        return this.getPrice_per_person();
    }

    //set
    public void setPrice_per_person(double price_per_person){
        this.price_per_person = price_per_person;
    }

    //String
    public String toString(){
        return "canteen: " + "\n\tPrice per person: " + this.price_per_person + "bath\n";
    }

    @Override
    public String Get_opening_time(String op_mon, String op_tue, String op_wed, String op_thu, String op_fri,String op_sat, String op_sun, String tel){
        // TODO Auto-generated method stub

        // print
        return "   Opening Time   "+"\n-----------------" + "\nMon " + op_mon + "\nTue "
                + op_tue + "\nWed " + op_wed + "\nThu " + op_thu + "\nFri " + op_fri + "\nSat " + op_sat +
                "\nSun " + op_sun + "\n-----------------" + "\nTel: " +tel;


//        System.out.println("   Opening Time   ");
//        System.out.println("-----------------");
//        System.out.println("MON "+op1);
//        System.out.println("Tue "+op2);
//        System.out.println("Wed "+op3);
//        System.out.println("Thu "+op4);
//        System.out.println("Fri "+op5);
//        System.out.println("Sat "+op6);
//        System.out.println("Sun "+op7);
//        System.out.println("-----------------");
//        System.out.println("Tel: "+tel);
    }
}
