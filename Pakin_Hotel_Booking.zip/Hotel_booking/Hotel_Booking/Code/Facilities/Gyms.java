package Facilities;

import Interfaces.Get_opening_time;

public class Gyms implements Get_opening_time {
    public String dumbell, running_machine, weigthing_scale, bike_machine;
    //String open_time, close_time;
    // default
    public Gyms(){
        this.dumbell = "No dumbell is available.";
        this.running_machine = "No running machine is available.";
        this.weigthing_scale = "No weigthing scale is available.";
        this.bike_machine = "No bike machine is available.";
//        this.oper_time = "default";
//          this.close_time = "default";
    }

    // value
    public Gyms(String dumbell,String running_machine, String weigthing_scale, String bike_machine){
        this.dumbell = dumbell;
        this.running_machine = running_machine;
        this.weigthing_scale = weigthing_scale;
        this.bike_machine = bike_machine;
//        this.open_time = open_time;
//        this.close_time = close_time;
    }

    //get
    public String getdumbell(){
        return this.dumbell;
    }

    public String getRunning_machine(){
        return this.running_machine;
    }

    public String getWeighing_scale(){
        return this.getWeighing_scale();
    }

    public String getBike_machine(){
        return this.bike_machine;
    }

    //set
    public void setDumbell(String dumbell){
        this.dumbell = dumbell;
    }

    public void setRunning_machine(String running_machine){
        this.running_machine = running_machine;
    }

    public void setWeigthing_scale(String weigthing_scale){
        this.weigthing_scale = weigthing_scale;
    }

    public void setBike_machine(String bike_machine){
        this.bike_machine = bike_machine;
    }

    //string
    public String toString(){
        return "Gyms: " + "\n\tDumbell: " + this.dumbell + "\n\tRunning machine: " + this.running_machine +
                "\n\tWeighing scale: " + weigthing_scale + "\n\tBike machine: " + this.bike_machine + "\n";
    }

    @Override
    public String Get_opening_time(String op_mon, String op_tue, String op_wed, String op_thu, String op_fri,String op_sat, String op_sun, String tel) {
        // TODO Auto-generated method stub

        // print
        return "   Opening Time   "+"\n-----------------" + "\nMon " + op_mon + "\nTue "
                + op_tue + "\nWed " + op_wed + "\nThu " + op_thu + "\nFri " + op_fri + "\nSat " + op_sat +
                "\nSun " + op_sun + "\n-----------------" + "\nTel: " +tel;

    }
}
