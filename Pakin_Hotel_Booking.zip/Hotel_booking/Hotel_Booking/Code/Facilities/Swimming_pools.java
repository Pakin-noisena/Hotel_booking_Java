package Facilities;

import Interfaces.Get_opening_time;


public class Swimming_pools implements Get_opening_time {
    public String adult_size;
    //    protected double adult_price,kid_price;
//    protected String open_time, close_time;
    public String kid_size;

    //default
    public Swimming_pools(){
        this.adult_size = "No adult size pool is available.";
        this.kid_size = "No kid size pool is available.";
//        this.adult_price = 0.0;
//        this.kid_price = 0.0;
//        this.open_time = "default";
//        this.close_time = "default";
    }

    //value
    public Swimming_pools(String adult_size,String kid_size){
        this.adult_size = adult_size;
        this.kid_size = kid_size;
//        this.adult_price = 0.0;
//        this.kid_price = 0.0;
//        this.open_time = "default";
//        this.close_time = "default";
    }

    //get
    public String getadult_size(){
        return this.adult_size;
    }

    public String getkid_size(){
        return this.kid_size;
    }

    //set
    public void setAdult_size(String adult_size){
        this.adult_size = adult_size;
    }

    public void setKid_size(String kid_size){
        this.kid_size = kid_size;
    }

    // string
    public String toString(){
        return "Swimming pool: " + "\n\tadult size: " + this.adult_size + "\n\tkid size: " + this.kid_size;
    }

    // Get_opening_time interface
    @Override
    public String Get_opening_time(String op_mon, String op_tue, String op_wed, String op_thu, String op_fri,String op_sat, String op_sun, String tel) {
        // TODO Auto-generated method stub

        // print
        return "   Opening Time   "+"\n-----------------" + "\nMon " + op_mon + "\nTue "
                + op_tue + "\nWed " + op_wed + "\nThu " + op_thu + "\nFri " + op_fri + "\nSat " + op_sat +
                "\nSun " + op_sun + "\n-----------------" + "\nTel: " +tel;
    }


}
