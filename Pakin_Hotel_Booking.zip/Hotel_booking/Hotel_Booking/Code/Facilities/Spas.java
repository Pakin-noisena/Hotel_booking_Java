package Facilities;


import Interfaces.Get_opening_time;


public class Spas implements Get_opening_time {
    public String face_spa;
    public String body_spa;
    public String foot_spa;

    //default
    public Spas(){
        this.face_spa = "No face spa is available.";
        this.body_spa = "No body spa is available.";
        this.foot_spa = "No foot spa is available.";
    }

    //value
    public Spas(String face_spa, String body_spa, String foot_spa){
        this.face_spa = face_spa;
        this.body_spa = body_spa;
        this.foot_spa = foot_spa;
    }

    //get
    public String getFace_spa(){
        return this.face_spa;
    }

    public String getBody_spa(){
        return this.body_spa;
    }

    public String getFoot_spa(){
        return this.foot_spa;
    }

    //set
    public void setFace_spa(String face_spa){
        this.face_spa = face_spa;
    }

    public void setBody_spa(String body_spa){
        this.body_spa = body_spa;
    }

    public void setFoot_spa(String foot_spa){
        this.foot_spa = foot_spa;
    }

    public String toString(){
        return "Spa: " + "\n\tFace spa: " + this.face_spa + "\n\tBody spa: " + this.body_spa +
                "\n\tFoot spa: " + this.foot_spa + "\n";
    }

    @Override
    public String Get_opening_time(String op_mon, String op_tue, String op_wed, String op_thu, String op_fri,String op_sat, String op_sun, String tel) {
        // TODO Auto-generated method stub

        // print
        return "   Opening Time   "+"\n-----------------" + "\nMon " + op_mon + "\nTue "
                + op_tue + "\nWed " + op_wed + "\nThu " + op_thu + "\nFri " + op_fri + "\nSat " + op_sat +
                "\nSun " + op_sun + "\n-----------------" + "\nTel: " +tel;
    }
}
