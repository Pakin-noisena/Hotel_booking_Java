package MAIN;
import java.sql.*;
import java.util.*;
import Facilities.*;
import Hotels.Hotels;
import Loggin.*;
import Payment.*;
import Rooms.*;
import Search.Booking;
import com.itextpdf.*;
import com.itextpdf.text.List;
import com.itextpdf.text.pdf.*;
import com.itextpdf.text.*;
import java.io.*;
// program running method
public class Program_running {
    // check in, check out , and guess number
    public static String din;
    public static String dout;
    public static int gn;
    //loggin object
    public static LOGGIN l = new LOGGIN();
    public static String location_answer;
    // Use scanner
    public static Scanner in = new Scanner(System.in);
    public static String location_selection; // scanner variable use in LocationSelection() method
    public static String hotel_selection; // Scanner variable use in Hotelselection() method
    public static String roomtype_selection; // Scanner variable use in RoomtypeSelection() method
    public static String choose_hotel; // Scanner variable use in Choose hotel() method
    public static String payment_option; // Scanner variable use in PaymentOption() method
    // array
    //*** hotel array ***
    public static String[] hotel_names_in_Bangkok = new String[2]; // declare array to store hotel name in Bangkok
    public static String[] hotel_names_in_Pattaya = new String[2]; // declare array to store hotel names in Pattaya
    public static Hotels[] hotels_in_Bangkok = new Hotels[2]; // declare array to store hotel object in Bangkok
    public static Hotels[] hotels_in_Pattaya = new Hotels[2]; // declare array to store hotel object in Pattaya
    public static String[] citys = new String[2]; // city array
    public static String[] addr = new String[4]; // address array
    //*** room array ***
    public static String[] roomtypes = new String[3]; // roomtype
    //***payment array***
    public static String[] payments = new String[3];
    //---------------Class & object zone---------------//
    //*** create hotel class ***
    // hotel 1
    public static Swimming_pools swp1 = new Swimming_pools("Yes","Yes"); // create swimming pool composite 1
    public static Gyms gym1 = new Gyms("Yes","Yes","Yes","Yes"); // create gyms composite 1
    public static Spas spa1 = new Spas("Yes","Yes","Yes"); // create spa composite 1
    public static Canteens can1 = new Canteens(45.0); // create canteen composite 1
    public static Hotels hotel_1 = new Hotels("Nova",swp1,gym1,spa1,can1);// create hotel 1
    // hotel 2
    public static Swimming_pools swp2 = new Swimming_pools("Yes","Yes"); // create swimming pool composite 2
    public static Gyms gym2 = new Gyms("Yes","Yes","Yes","Yes"); // create gyms composite 2
    public static Spas spa2 = new Spas("Yes","Yes","Yes"); // create spa composite 2
    public static Canteens can2 = new Canteens(45.0); // create canteen composite 2

    public static Hotels hotel_2 = new Hotels("Iris",swp2,gym2,spa2,can2); // create hotel 2
    // hotel 3
    public static Swimming_pools swp3 = new Swimming_pools("Yes","Yes"); // create swimming pool composite 3
    public static Gyms gym3 = new Gyms("Yes","Yes","Yes","Yes"); // create gyms composite 3
    public static Spas spa3 = new Spas("Yes","Yes","Yes"); // create spa composite 3
    public static Canteens can3 = new Canteens(45.0); // create canteen composite 3

    public static Hotels hotel_3 = new Hotels("Balihi Bay",swp3,gym3,spa3,can3); // create hotel 3
    // hotel 4
    public static Swimming_pools swp4 = new Swimming_pools("Yes","Yes"); // create swimming pool composite 4
    public static  Gyms gym4 = new Gyms("Yes","Yes","Yes","Yes"); // create gyms composite 4
    public static Spas spa4 = new Spas("Yes","Yes","Yes"); // create spa composite 4
    public static Canteens can4 = new Canteens(45.0); // create canteen composite 4

    public static Hotels hotel_4 = new Hotels("View Talay",swp4,gym4,spa4,can4); // create hotel 4
    //*** create room type class ***//
    // roomtype for hotel 1(Nova)
    public static Single_room sr1 = new Single_room(1400.0, 36.5, "City view","Single bed", "Yes", "Yes", "No", "Yes");
    public static Family_room fr1 = new Family_room(2500.0, 50.0, "City view", "2 King bed", "Yes", "Yes", "No", "Yes", "1 Baby bed");
    public static Suite sur1 = new Suite(1800.0, 42.0, "City view", "King bed", "Yes", "Yes", "No", "Yes", "Yes", "Yes");
    // roomtype for hotel 2(Iris)
    public static Single_room sr2 = new Single_room(1400.0, 36.5, "City view", "Single bed", "Yes", "Yes", "No", "Yes");
    public static Family_room fr2 = new Family_room(2500.0, 50.0, "City view", "2 King bed", "Yes", "Yes", "No", "Yes", "1 Baby bed");
    public static Suite sur2 = new Suite(1800.0, 42.0, "City view", "King bed", "Yes", "Yes", "No", "Yes", "Yes", "Yes");
    // roomtype for hotel 3(Balihi Bay)
    public static Single_room sr3 = new Single_room(1400.0, 36.5, "Garden view", "Single bed", "Yes", "Yes", "No", "Yes");
    public static Family_room fr3 = new Family_room(2500.0, 50.0, "City view", "2 King bed", "Yes", "Yes", "No", "Yes", "1 Baby bed");
    public static Suite sur3 = new Suite(1800.0, 42.0, "Sea view", "King bed", "Yes", "Yes", "No", "Yes", "Yes", "Yes");
    // roomtype for hotel 4(View Talay)
    public static Single_room sr4 = new Single_room(1400.0, 36.5, "Garden view", "Single bed", "Yes", "Yes", "No", "Yes");
    public static Family_room fr4 = new Family_room(2500.0, 50.0, "City view", "2 King bed", "Yes", "Yes", "No", "Yes", "1 Baby bed");
    public static Suite sur4 = new Suite(1800.0, 42.0, "Sea view", "King bed", "Yes", "Yes", "No", "Yes", "Yes", "Yes");
    // card subclass interface (invoice super class)
    public static String check_name;
    public static String visa;
    public static String credit;
    public static String name_on_card;
    public static int number_on_card;
    public static int cw;
    // pdf return variable method
    public static Document document;

    public static void Meth() {
        // get hotel class name function
        String  hotel_name1 =  hotel_1.getname(); // hotel1 name = Nova
        String hotel_name2 = hotel_2.getname(); // hotel2 name = Iris
        String hotel_name3 = hotel_3.getname(); // hotel3 name = Balihi Bay
        String hotel_name4 = hotel_4.getname(); // hotel4 name = View Talay

        citys[0] = "Bangkok";
        citys[1] = "Pattaya";

        //store hotel object in array that have Bangkok city
        hotels_in_Bangkok[0] = hotel_1;
        hotels_in_Bangkok[1] = hotel_2;

        // store Pattaya hotel object  in array that have Pattaya city
        hotels_in_Pattaya[0] = hotel_3;
        hotels_in_Pattaya[1] = hotel_4;

        //store hotel name in array in Bangkok
        hotel_names_in_Bangkok[0] = hotel_name1;
        hotel_names_in_Bangkok[1] = hotel_name2;

        //hotel name array in Pattaya
        hotel_names_in_Pattaya[0] = hotel_name3;
        hotel_names_in_Pattaya[1] = hotel_name4;

        // create address
        addr[0] = "181/1-5 Surawong road, Suriyawong, Bangluck, Srilom"; // address for Nova
        addr[1] = "488/800 Bobe tower, Klong Mahanark, Pomprab, Kawsarn,"; // array for Iris
        addr[2] = "481 Moo 10, Soi 10, Jomtien road, Nongprue"; // array for Balihi Bay
        addr[3] = "399/9-10 Moo 9, Chaleumprakriet,South Pattaya,"; // array for View Talay

        // store roomtype array
        roomtypes[0] = "Single";
        roomtypes[1] = "Family";
        roomtypes[2] = "Suite";

        // store payment type array
        payments[0] = "Card";
        payments[1] = "Cash";
        payments[2] = "Online banking";

        // programm running
//         Check in and check out
        System.out.println("Check-in Date (yyyy-mm-dd): ");
         din = in.nextLine();

        System.out.println("Check-out Date (yyyy-mm-dd): ");
         dout = in.nextLine();

        System.out.println("Number of guest: ");
         gn = in.nextInt();
        in.nextLine();

        Booking b = new Booking(din, dout, gn);

        String program_loop = "0";
        while(program_loop.equals("0")) {
            // location selection method
            LocationSelection();

            // hotel selection method
            Hotelselection();

            // room type selection method
            RoomtypeSelection();

            // choose hotel method
            ChooseHotel();

            //Booking confirm method
            BookingConfirm();

            //Patment option method
            PaymentOption();

            // condition to quit or loop
            System.out.print("Type (Q)uit to quit, anything to restart: ");
            String loop = in.nextLine();
            if(loop.equalsIgnoreCase("Q")||loop.equalsIgnoreCase("quit")){
                break;
            }
            else{

            }
        }
    }
    // local selection method
    public static  void  LocationSelection(){


        // localselection method
        String location_error = "0";
        while(location_error.equals("0")) { // if the user input the random location value

            // location selection interface
            System.out.print("Choose location (Type Q to exit): ");
            location_selection = in.nextLine();
            System.out.println("-----------------------");

            // if location selection = location1 (Bangkok)
            if (location_selection.equalsIgnoreCase("b") || location_selection.equalsIgnoreCase(citys[0])) {
                for(int i =0; i<hotel_names_in_Bangkok.length;i++){
                    System.out.println(hotel_names_in_Bangkok[i]);

                }
                System.out.println("-----------------------");
                break;
            }
            // if location selection = location2 (Pattaya)
            else if (location_selection.equalsIgnoreCase("p") || location_selection.equalsIgnoreCase(citys[1])) {
                for(int i = 0; i<hotel_names_in_Pattaya.length; i++){
                    System.out.println(hotel_names_in_Pattaya[i]);

                }
                System.out.println("-----------------------");
                break;
            }
            // exit the program
            else if(location_selection.equalsIgnoreCase("q")){
                System.exit(0) ; // exit funtion
                break;
            }
            else{
                System.out.println("Please selection the correct location.");
                System.out.println("-----------------------");
                for(int i = 0; i < citys.length; i++){
                    System.out.println(citys[i]);
                }
                System.out.println("-----------------------");
            }
        }
    }

    // hotel selection method
    public static void Hotelselection(){

        String hotel_error = "0";
        while(hotel_error.equals("0")) { // use to loop when go to else


            System.out.print("Select hotel (Type P to previous, Q to exit): ");
            hotel_selection = in.nextLine();
            System.out.println("-----------------------");

            // hotel selection = Nova
            if (hotel_selection.equalsIgnoreCase(hotel_names_in_Bangkok[0]) && (location_selection.equalsIgnoreCase(citys[0]) ||location_selection.equalsIgnoreCase("b"))) {

                System.out.println(hotel_1.Get_city(citys[0])); // print hotel 1 city = Bangkok
                System.out.println(hotel_1.Get_country("Thailand")); // print country = Thailand
                System.out.println(hotel_1.Get_address_line(addr[0])); // print hotel1 address
                System.out.println(hotels_in_Bangkok[0]); // print hotel object (with composite)
                System.out.println("-----------------------");
                break;
            }
            //hotel selection = Iris
            else if (hotel_selection.equalsIgnoreCase(hotel_names_in_Bangkok[1]) && (location_selection.equalsIgnoreCase("b") || location_selection.equalsIgnoreCase(citys[0]))) {
                System.out.println(hotel_2.Get_city(citys[0])); // print hotel 2 city = Bangkok
                System.out.println(hotel_2.Get_country("Thailand")); // print country = Thailand
                System.out.println(hotel_2.Get_address_line(addr[1])); // print hotel2 address
                System.out.println(hotels_in_Bangkok[1]); // print hotel object (with composite)
                System.out.println("-----------------------");
                break;
            }
            //hotel selection = Balihi Bay
            else if (hotel_selection.equalsIgnoreCase(hotel_names_in_Pattaya[0]) && (location_selection.equalsIgnoreCase("p") || location_selection.equalsIgnoreCase(citys[1]))) {

                System.out.println(hotel_3.Get_city(citys[1])); // print hotel 3 city = Pattaya
                System.out.println(hotel_3.Get_country("Thailand")); // print county = Thailand
                System.out.println(hotel_3.Get_address_line(addr[2])); //print hotel3 address
                System.out.println(hotels_in_Pattaya[0]); // print hotel object (with composite)
                System.out.println("-----------------------");
                break;
            }
            // hotel selection = View Talay
            else if (hotel_selection.equalsIgnoreCase(hotel_names_in_Pattaya[1]) && (location_selection.equalsIgnoreCase("p") || location_selection.equalsIgnoreCase("Pattaya"))) {

                System.out.println(hotel_4.Get_city(citys[1])); // print hotel 4 city = Pattaya
                System.out.println(hotel_4.Get_country("Thailand")); // print country = Thailand
                System.out.println(hotel_4.Get_address_line(addr[3])); // print hotel4 address
                System.out.println(hotels_in_Pattaya[1]); // print hotel object (with composite)
                System.out.println("-----------------------");
                break;
            }
            //exit the program
            else if (hotel_selection.equalsIgnoreCase("q")) {
                System.exit(0); // exit funtion
                break;
            }
            // to go back to location selection
            else if (hotel_selection.equalsIgnoreCase("P") || hotel_selection.equalsIgnoreCase("previous")) {
                LocationSelection();
            }

            // the if the value input is random
            else {
                System.out.println("Please select the correct hotel.");
                // if location selection = location1 (Bangkok)
                if (location_selection.equalsIgnoreCase("b") || location_selection.equalsIgnoreCase(citys[0])) {
                    for (int i = 0; i < hotel_names_in_Bangkok.length; i++) {
                        System.out.println(hotel_names_in_Bangkok[i]);

                    }
                }
                // if location selection = location2 (Pattaya)
                else if (location_selection.equalsIgnoreCase("p") || location_selection.equalsIgnoreCase(citys[1])) {
                    for (int i = 0; i < hotel_names_in_Pattaya.length; i++) {
                        System.out.println(hotel_names_in_Pattaya[i]);

                    }
                }
                System.out.println("-----------------------");
            }
        }
    }
    // roomtype selection method
    public static void RoomtypeSelection(){
        String roomtype_error = "0";
        while(roomtype_error.equals("0")){ // if the user input the random value and type Previous

            // rootype selection interface user input
            for(int i = 0; i<roomtypes.length; i++){
                System.out.println(roomtypes[i]);
            }
            System.out.println("-----------------------");
            System.out.print("Select room type (Type P to previous, Q to quit): ");
            roomtype_selection = in.nextLine();
            System.out.println("-----------------------");

            //***hotel1***//
            // if Nova hotel roomtype = single room
            if(roomtype_selection.equalsIgnoreCase(roomtypes[0]) && hotel_selection.equalsIgnoreCase(hotel_names_in_Bangkok[0])){
                System.out.println(sr1);

                break;
            }
            // if Nova hotel roomtype = family room
            else if(roomtype_selection.equalsIgnoreCase(roomtypes[1]) && hotel_selection.equalsIgnoreCase(hotel_names_in_Bangkok[0])){
                System.out.println(fr1);
                break;
            }
            // if Nova hotel roomtype = suite room
            else if(roomtype_selection.equalsIgnoreCase(roomtypes[2]) && hotel_selection.equalsIgnoreCase(hotel_names_in_Bangkok[0])){
                System.out.println(sur1);
                break;
            }
            //***hotel2***//
            //if Iris hotel roomtype = single room
            else if(roomtype_selection.equalsIgnoreCase(roomtypes[0]) && hotel_selection.equalsIgnoreCase(hotel_names_in_Bangkok[1])){
                System.out.println(sr2);
                break;
            }
            // if Iris hotel roomtype = family room
            else if(roomtype_selection.equalsIgnoreCase(roomtypes[1]) && hotel_selection.equalsIgnoreCase(hotel_names_in_Bangkok[1])){
                System.out.println(fr2);
                break;
            }
            // if Iris hotel roomtype = suite room
            else if(roomtype_selection.equalsIgnoreCase(roomtypes[2]) && hotel_selection.equalsIgnoreCase(hotel_names_in_Bangkok[1])){
                System.out.println(sur2);
                break;
            }
            //***hotel3***//
            // if Balihi Bay = single room
            else if(roomtype_selection.equalsIgnoreCase(roomtypes[0]) && hotel_selection.equalsIgnoreCase(hotel_names_in_Pattaya[0])){
                System.out.println(sr3);
                break;
            }
            // if Balihi Bay = family room
            else if(roomtype_selection.equalsIgnoreCase(roomtypes[1]) && hotel_selection.equalsIgnoreCase(hotel_names_in_Pattaya[0])){
                System.out.println(fr3);
                break;
            }
            // if Balihi Bay = suite room
            else if(roomtype_selection.equalsIgnoreCase(roomtypes[2]) && hotel_selection.equalsIgnoreCase(hotel_names_in_Pattaya[0])){
                System.out.println(sur3);
                break;
            }
            //***hotel4***//
            //if View Talay = single room
            else if(roomtype_selection.equalsIgnoreCase(roomtypes[0]) && hotel_selection.equalsIgnoreCase(hotel_names_in_Pattaya[1])){
                System.out.println(sr4);
                break;
            }
            // if View Talay = family room
            else if(roomtype_selection.equalsIgnoreCase(roomtypes[1]) && hotel_selection.equalsIgnoreCase(hotel_names_in_Pattaya[1])){
                System.out.println(fr4);
                break;
            }
            // if View Talay = suite room
            else if(roomtype_selection.equalsIgnoreCase(roomtypes[2]) && hotel_selection.equalsIgnoreCase(hotel_names_in_Pattaya[1])){
                System.out.println(sur4);
                break;
            }
            // type q to exit
            else if(roomtype_selection.equalsIgnoreCase("q")){
                System.exit(0) ; // exit funtion
                break;
            }
            // type p to previous
            else if(roomtype_selection.equalsIgnoreCase("P")){
                if (location_selection.equalsIgnoreCase("b") || location_selection.equalsIgnoreCase(citys[0])) {
                    for (int i = 0; i < hotel_names_in_Bangkok.length; i++) {
                        System.out.println(hotel_names_in_Bangkok[i]);

                    }
                }
                // if location selection = location2 (Pattaya)
                else if (location_selection.equalsIgnoreCase("p") || location_selection.equalsIgnoreCase(citys[1])) {
                    for (int i = 0; i < hotel_names_in_Pattaya.length; i++) {
                        System.out.println(hotel_names_in_Pattaya[i]);

                    }
                }
                System.out.println("-----------------------");
                Hotelselection();

            }
            // if the value input is random
            else{
                System.out.println("Please select the correct roomtype.");
                System.out.println("-----------------------");
            }

        }
    }

    // Choose hotel method
    public static void ChooseHotel(){
        String choose_error = "0";
        while(choose_error.equals("0")){ // if the user input the random value

            // user input interface
            System.out.println("-----------------------");
            System.out.print("Choose this hotel (Type (Y)es or (N)o): ");
            choose_hotel = in.nextLine();
            System.out.println("-----------------------");

            // if user input = confirm
            if(choose_hotel.equalsIgnoreCase("y")|| choose_hotel.equalsIgnoreCase("yes")){
                //***hotel1***//
                // if Nova hotel roomtype = single room
                if(roomtype_selection.equalsIgnoreCase(roomtypes[0]) && hotel_selection.equalsIgnoreCase(hotel_names_in_Bangkok[0])){
                    System.out.println(hotel_1.Get_city(citys[0])); // print hotel 1 city = Bangkok
                    System.out.println(hotel_1.Get_country("Thailand")); // print country = Thailand
                    System.out.println(hotel_1.Get_address_line(addr[0])); // print hotel1 address
                    System.out.println(hotels_in_Bangkok[0]); // print hotel object (with composite)
                    System.out.println(sr1); // print single room
                    System.out.println("-----------------------");

                }
                // if Nova hotel roomtype = family room
                else if(roomtype_selection.equalsIgnoreCase(roomtypes[1]) && hotel_selection.equalsIgnoreCase(hotel_names_in_Bangkok[0])){
                    System.out.println(hotel_1.Get_city(citys[0])); // print hotel 1 city = Bangkok
                    System.out.println(hotel_1.Get_country("Thailand")); // print country = Thailand
                    System.out.println(hotel_1.Get_address_line(addr[0])); // print hotel1 address
                    System.out.println(hotels_in_Bangkok[0]); // print hotel object (with composite)
                    System.out.println(fr1); // print single room
                    System.out.println("-----------------------");
                }
                // if Nova hotel roomtype = suite room
                else if(roomtype_selection.equalsIgnoreCase(roomtypes[2]) && hotel_selection.equalsIgnoreCase(hotel_names_in_Bangkok[0])) {
                    System.out.println(hotel_1.Get_city(citys[0])); // print hotel 1 city = Bangkok
                    System.out.println(hotel_1.Get_country("Thailand")); // print country = Thailand
                    System.out.println(hotel_1.Get_address_line(addr[0])); // print hotel1 address
                    System.out.println(hotels_in_Bangkok[0]); // print hotel object (with composite)
                    System.out.println(sur1); // print single room
                    System.out.println("-----------------------");
                }
                //***hotel2***//
                //if Iris hotel roomtype = single room
                else if(roomtype_selection.equalsIgnoreCase(roomtypes[0]) && hotel_selection.equalsIgnoreCase(hotel_names_in_Bangkok[1])){
                    System.out.println(hotel_2.Get_city(citys[0])); // print hotel 1 city = Bangkok
                    System.out.println(hotel_2.Get_country("Thailand")); // print country = Thailand
                    System.out.println(hotel_2.Get_address_line(addr[1])); // print hotel1 address
                    System.out.println(hotels_in_Bangkok[1]); // print hotel object (with composite)
                    System.out.println(sr2); // print single room
                    System.out.println("-----------------------");
                }
                //if Iris hotel roomtype = family room
                else if(roomtype_selection.equalsIgnoreCase(roomtypes[1]) && hotel_selection.equalsIgnoreCase(hotel_names_in_Bangkok[1])){
                    System.out.println(hotel_2.Get_city(citys[0])); // print hotel 1 city = Bangkok
                    System.out.println(hotel_2.Get_country("Thailand")); // print country = Thailand
                    System.out.println(hotel_2.Get_address_line(addr[1])); // print hotel1 address
                    System.out.println(hotels_in_Bangkok[1]); // print hotel object (with composite)
                    System.out.println(fr2); // print family room
                    System.out.println("-----------------------");
                }
                //if Iris hotel roomtype = suite room
                else if(roomtype_selection.equalsIgnoreCase(roomtypes[2]) && hotel_selection.equalsIgnoreCase(hotel_names_in_Bangkok[1])){
                    System.out.println(hotel_2.Get_city(citys[0])); // print hotel 1 city = Bangkok
                    System.out.println(hotel_2.Get_country("Thailand")); // print country = Thailand
                    System.out.println(hotel_2.Get_address_line(addr[1])); // print hotel1 address
                    System.out.println(hotels_in_Bangkok[1]); // print hotel object (with composite)
                    System.out.println(sur2); // print suite room
                    System.out.println("-----------------------");
                }
                //***hotel3***//
                // if Balihi Bay roomtype = single room
                else if(roomtype_selection.equalsIgnoreCase(roomtypes[0]) && hotel_selection.equalsIgnoreCase(hotel_names_in_Pattaya[0])){
                    System.out.println(hotel_3.Get_city(citys[1])); // print hotel 1 city = Pattaya
                    System.out.println(hotel_3.Get_country("Thailand")); // print country = Thailand
                    System.out.println(hotel_3.Get_address_line(addr[2])); // print hotel1 address
                    System.out.println(hotels_in_Pattaya[0]); // print hotel object (with composite)
                    System.out.println(sr3);
                    System.out.println("-----------------------");
                }
                // if Balihi Bay roomtype = family room
                else if(roomtype_selection.equalsIgnoreCase(roomtypes[1]) && hotel_selection.equalsIgnoreCase(hotel_names_in_Pattaya[0])){
                    System.out.println(hotel_3.Get_city(citys[1])); // print hotel 1 city = Pattaya
                    System.out.println(hotel_3.Get_country("Thailand")); // print country = Thailand
                    System.out.println(hotel_3.Get_address_line(addr[2])); // print hotel1 address
                    System.out.println(hotels_in_Pattaya[0]); // print hotel object (with composite)
                    System.out.println(fr3);
                    System.out.println("-----------------------");
                }
                // if Balihi Bay roomtype = suite room
                else if(roomtype_selection.equalsIgnoreCase(roomtypes[2]) && hotel_selection.equalsIgnoreCase(hotel_names_in_Pattaya[0])){
                    System.out.println(hotel_3.Get_city(citys[1])); // print hotel 1 city = Pattaya
                    System.out.println(hotel_3.Get_country("Thailand")); // print country = Thailand
                    System.out.println(hotel_3.Get_address_line(addr[2])); // print hotel1 address
                    System.out.println(hotels_in_Pattaya[0]); // print hotel object (with composite)
                    System.out.println(sur3);
                    System.out.println("-----------------------");
                }
                //***hotel4***//
                // if View Talay roomtype = single room
                else if(roomtype_selection.equalsIgnoreCase(roomtypes[0]) && hotel_selection.equalsIgnoreCase(hotel_names_in_Pattaya[1])){
                    System.out.println(hotel_4.Get_city(citys[1])); // print hotel 4 city = Pattaya
                    System.out.println(hotel_4.Get_country("Thailand")); // print country = Thailand
                    System.out.println(hotel_4.Get_address_line(addr[3])); // print hotel4 address
                    System.out.println(hotels_in_Pattaya[1]); // print hotel object (with composite)
                    System.out.println(sr4);
                    System.out.println("-----------------------");
                }
                // if View Talay roomtype = family room
                else if(roomtype_selection.equalsIgnoreCase(roomtypes[1]) && hotel_selection.equalsIgnoreCase(hotel_names_in_Pattaya[1])){
                    System.out.println(hotel_4.Get_city(citys[1])); // print hotel 4 city = Pattaya
                    System.out.println(hotel_4.Get_country("Thailand")); // print country = Thailand
                    System.out.println(hotel_4.Get_address_line(addr[3])); // print hotel4 address
                    System.out.println(hotels_in_Pattaya[1]); // print hotel object (with composite)
                    System.out.println(fr4);
                    System.out.println("-----------------------");
                }
                // if View Talay, roomtype = suite room
                else if(roomtype_selection.equalsIgnoreCase(roomtypes[2]) && hotel_selection.equalsIgnoreCase(hotel_names_in_Pattaya[1])){
                    System.out.println(hotel_4.Get_city(citys[1])); // print hotel 4 city = Pattaya
                    System.out.println(hotel_4.Get_country("Thailand")); // print country = Thailand
                    System.out.println(hotel_4.Get_address_line(addr[3])); // print hotel4 address
                    System.out.println(hotels_in_Pattaya[1]); // print hotel object (with composite)
                    System.out.println(sur4);
                    System.out.println("-----------------------");
                }

                else{

                }
                break;
            }
            else if(choose_hotel.equalsIgnoreCase("n")||choose_hotel.equalsIgnoreCase("no")){
                LocationSelection();
                Hotelselection();
                RoomtypeSelection();
            }
            else{

            }
        }
    }
    // Booking confirm method
    public static void BookingConfirm(){
        String booking_confirm_error = "0";
        while(booking_confirm_error.equals("0")){ // if the user input the random value
            // interface
            System.out.print("Booking confirm (Type (Con)firm or (Can)cel): ");
            String booking_confirm = in.nextLine();
            System.out.println("-----------------------");

            if(booking_confirm.equalsIgnoreCase("con")||booking_confirm.equalsIgnoreCase("confirm")){
                System.out.println("Booking has been confirmed.");
                break;
            }
            else if(booking_confirm.equalsIgnoreCase("can")||booking_confirm.equalsIgnoreCase("cancel")){
                LocationSelection();
                Hotelselection();
                RoomtypeSelection();
                ChooseHotel();
            }
            else{

            }
        }
    }
    // payment option selection method
    public static void PaymentOption(){

        String payment_option_error = "0";
        while(payment_option_error.equals("0")){ // if the user input the random value

            //user input interface
            System.out.println("-----------------------");
            for(int i = 0; i < payments.length; i++){
                System.out.println(payments[i]);
            }
            System.out.println("-----------------------");
            System.out.print("Select payment option (Type Q to quit, P to previous): ");
            payment_option = in.nextLine();
            System.out.println("-----------------------");

            // if payment option = Card
            if(payment_option.equalsIgnoreCase(payments[0])){
                //***Hotel1 Nova, roomtype single room***//
                if(roomtype_selection.equalsIgnoreCase(roomtypes[0]) && hotel_selection.equalsIgnoreCase(hotel_names_in_Bangkok[0])){

                    CardInterface(); // card interface method

                    // create invoice class for using function
                    Invoices inv1 = new Invoices(sr1.getprice(),0.3);
                    // create card class
                    Receipts rec1 = new Receipts(hotel_1.getname(),check_name,"room charge",06,1,sr1.getprice(),inv1.Amount(),inv1.Booking_Date());
                    // loggin insert
                        try {
	                        Connection con = getConnection();
	                        PreparedStatement create = con.prepareStatement("INSERT INTO room (Type, Price, Status, Check_in_name, User_ID, Hotel_ID, Check_in, Check_out, Guest_NO) VALUES"
			                + " ( " + "'" + roomtype_selection + "'" + " , " + "'" + rec1.getTotal() + "'" + ", 'Paid',  " + "'" + check_name + "'" + ",(SELECT user.ID FROM user WHERE user.F_name = " + "'" + l.Logginname() + "'" + " ), 1," + "'" + din   + "',"+ "'" +  dout  + "',"+ "'" +  gn  + "'" + ") ;");
	                        create.executeUpdate();
	                        }catch(Exception e) { System.out.println(e);}
                            finally {
	                        System.out.println("Function complete");
                            };
                        Card card1 = new Card(sr1.getprice(),0.3,"Yes",rec1,visa,credit,name_on_card,number_on_card,cw);
                        System.out.println(card1);
                        // print as pdf
                    System.out.println(PdfReceiptCard(hotel_1.getname(),06,inv1.Booking_Date(),(0.3*sr1.getprice()),sr1.getprice(),inv1.Amount()));
                }
                //***Hotel Nova, roomtype family room***//
                else if(roomtype_selection.equalsIgnoreCase(roomtypes[1]) && hotel_selection.equalsIgnoreCase(hotel_names_in_Bangkok[0])){

                    CardInterface(); //card interface method

                    // create invoice class for using function
                    Invoices inv2 = new Invoices(fr1.getprice(),0.3);
                    // create card class
                    Receipts rec2 = new Receipts(hotel_1.getname(),check_name,"room charge",06,1,fr1.getprice(),inv2.Amount(),inv2.Booking_Date());
                    // loggin insert
                    try {
                        Connection con = getConnection();
                        PreparedStatement create = con.prepareStatement("INSERT INTO room (Type, Price, Status, Check_in_name, User_ID, Hotel_ID, Check_in, Check_out, Guest_NO) VALUES"
                                + " ( " + "'" + roomtype_selection + "'" + " , " + "'" + rec2.getTotal() + "'" + ", 'Paid',  " + "'" + check_name + "'" + ",(SELECT user.ID FROM user WHERE user.F_name = " + "'" + l.Logginname() + "'" + " ), 1," + "'" + din   + "',"+ "'" +  dout  + "',"+ "'" +  gn  + "'" + ") ;");
                        create.executeUpdate();
                    }catch(Exception e) { System.out.println(e);}
                    finally {
                        System.out.println("Function complete");
                    }

                    Card card2 = new Card(fr1.getprice(),0.3,"Yes",rec2,visa,credit,name_on_card,number_on_card,cw);
                    System.out.println(card2);
                    // print pdf
                    System.out.println(PdfReceiptCard(hotel_1.getname(),06,inv2.Booking_Date(),(0.3*fr1.getprice()),fr1.getprice(),inv2.Amount()));
                }
                //***Hotel Nova, roomtype suite room***//
                else if(roomtype_selection.equalsIgnoreCase(roomtypes[2]) && hotel_selection.equalsIgnoreCase(hotel_names_in_Bangkok[0])){
                    CardInterface(); //card interface method

                    // create invoice class for using function
                    Invoices inv3 = new Invoices(sur1.getprice(),0.3);
                    // create card class
                    Receipts rec3 = new Receipts(hotel_1.getname(),check_name,"room charge",06,1,sur1.getprice(),inv3.Amount(),inv3.Booking_Date());
                    try {
                        Connection con = getConnection();
                        PreparedStatement create = con.prepareStatement("INSERT INTO room (Type, Price, Status, Check_in_name, User_ID, Hotel_ID, Check_in, Check_out, Guest_NO) VALUES"
                                + " ( " + "'" + roomtype_selection + "'" + " , " + "'" + rec3.getTotal() + "'" + ", 'Paid',  " + "'" + check_name + "'" + ",(SELECT user.ID FROM user WHERE user.F_name = " + "'" + l.Logginname() + "'" + " ), 1," + "'" + din   + "',"+ "'" +  dout  + "',"+ "'" +  gn  + "'" + ") ;");
                        create.executeUpdate();
                    }catch(Exception e) { System.out.println(e);}
                    finally {
                        System.out.println("Function complete");
                    };
                    Card card3 = new Card(sur1.getprice(),0.3,"Yes",rec3,visa,credit,name_on_card,number_on_card,cw);
                    System.out.println(card3);
                    // prinf pdf
                    System.out.println(PdfReceiptCard(hotel_1.getname(),06,inv3.Booking_Date(),(0.3*sur1.getprice()),sur1.getprice(),inv3.Amount()));
                }
                //***Hotel Iris, roomtype single room***//
                else if(roomtype_selection.equalsIgnoreCase(roomtypes[0]) && hotel_selection.equalsIgnoreCase(hotel_names_in_Bangkok[1])){
                    CardInterface(); //card interface method

                    // create invoice class for using function
                    Invoices inv4 = new Invoices(sr2.getprice(),0.3);
                    // create card class
                    Receipts rec4 = new Receipts(hotel_2.getname(),check_name,"room charge",06,1,sur1.getprice(),inv4.Amount(),inv4.Booking_Date());
                    try {
                        Connection con = getConnection();
                        PreparedStatement create = con.prepareStatement("INSERT INTO room (Type, Price, Status, Check_in_name, User_ID, Hotel_ID, Check_in, Check_out, Guest_NO) VALUES"
                                + " ( " + "'" + roomtype_selection + "'" + " , " + "'" + rec4.getTotal() + "'" + ", 'Paid',  " + "'" + check_name + "'" + ",(SELECT user.ID FROM user WHERE user.F_name = " + "'" + l.Logginname() + "'" + " ), 2," + "'" + din   + "',"+ "'" +  dout  + "',"+ "'" +  gn  + "'" + ") ;");
                        create.executeUpdate();
                    }catch(Exception e) { System.out.println(e);}
                    finally {
                        System.out.println("Function complete");
                    };
                    Card card4 = new Card(sr2.getprice(),0.3,"Yes",rec4,visa,credit,name_on_card,number_on_card,cw);
                    System.out.println(card4);
                    // print pdf
                    System.out.println(PdfReceiptCard(hotel_2.getname(),06,inv4.Booking_Date(),(0.3*sr2.getprice()),sr2.getprice(),inv4.Amount()));
                }
                //***Hotel Iris, roomtype family room***//
                else if(roomtype_selection.equalsIgnoreCase(roomtypes[1]) && hotel_selection.equalsIgnoreCase(hotel_names_in_Bangkok[1])){
                    CardInterface(); //card interface method

                    // create invoice class for using function
                    Invoices inv5 = new Invoices(fr2.getprice(),0.3);
                    // create card class
                    Receipts rec5 = new Receipts(hotel_2.getname(),check_name,"room charge",06,1,fr2.getprice(),inv5.Amount(),inv5.Booking_Date());
                    try {
                        Connection con = getConnection();
                        PreparedStatement create = con.prepareStatement("INSERT INTO room (Type, Price, Status, Check_in_name, User_ID, Hotel_ID, Check_in, Check_out, Guest_NO) VALUES"
                                + " ( " + "'" + roomtype_selection + "'" + " , " + "'" + rec5.getTotal() + "'" + ", 'Paid',  " + "'" + check_name + "'" + ",(SELECT user.ID FROM user WHERE user.F_name = " + "'" + l.Logginname() + "'" + " ), 2," + "'" + din   + "',"+ "'" +  dout  + "',"+ "'" +  gn  + "'" + ") ;");
                        create.executeUpdate();
                    }catch(Exception e) { System.out.println(e);}
                    finally {
                        System.out.println("Function complete");
                    };
                    Card card5 = new Card(fr2.getprice(),0.3,"Yes",rec5,visa,credit,name_on_card,number_on_card,cw);
                    System.out.println(card5);
                    // print pdf
                    System.out.println(PdfReceiptCard(hotel_2.getname(),06,inv5.Booking_Date(),(0.3*fr2.getprice()),fr2.getprice(),inv5.Amount()));
                }
                //***Hotel Iris, roomtype suite room***//
                else if(roomtype_selection.equalsIgnoreCase(roomtypes[2]) && hotel_selection.equalsIgnoreCase(hotel_names_in_Bangkok[1])){
                    CardInterface(); //card interface method

                    // create invoice class for using function
                    Invoices inv6 = new Invoices(sur2.getprice(),0.3);
                    // create card class
                    Receipts rec6 = new Receipts(hotel_2.getname(),check_name,"room charge",06,1,sur2.getprice(),inv6.Amount(),inv6.Booking_Date());
                    try {
                        Connection con = getConnection();
                        PreparedStatement create = con.prepareStatement("INSERT INTO room (Type, Price, Status, Check_in_name, User_ID, Hotel_ID, Check_in, Check_out, Guest_NO) VALUES"
                                + " ( " + "'" + roomtype_selection + "'" + " , " + "'" + rec6.getTotal() + "'" + ", 'Paid',  " + "'" + check_name + "'" + ",(SELECT user.ID FROM user WHERE user.F_name = " + "'" + l.Logginname() + "'" + " ), 2," + "'" + din   + "',"+ "'" +  dout  + "',"+ "'" +  gn  + "'" + ") ;");
                        create.executeUpdate();
                    }catch(Exception e) { System.out.println(e);}
                    finally {
                        System.out.println("Function complete");
                    };
                    Card card6 = new Card(sur2.getprice(),0.3,"Yes",rec6,visa,credit,name_on_card,number_on_card,cw);
                    System.out.println(card6);
                    // print pdf
                    System.out.println(PdfReceiptCard(hotel_2.getname(),06,inv6.Booking_Date(),(0.3*sur2.getprice()),sur2.getprice(),inv6.Amount()));
                }
                //*** Hotel Balihi Bay, roomtype single room
                else if(roomtype_selection.equalsIgnoreCase(roomtypes[0]) && hotel_selection.equalsIgnoreCase(hotel_names_in_Pattaya[0])){
                    CardInterface(); //card interface method

                    // create invoice class for using function
                    Invoices inv7 = new Invoices(sr3.getprice(),0.3);
                    // create card class
                    Receipts rec7 = new Receipts(hotel_3.getname(),check_name,"room charge",06,1,sr3.getprice(),inv7.Amount(),inv7.Booking_Date());
                    try {
                        Connection con = getConnection();
                        PreparedStatement create = con.prepareStatement("INSERT INTO room (Type, Price, Status, Check_in_name, User_ID, Hotel_ID, Check_in, Check_out, Guest_NO) VALUES"
                                + " ( " + "'" + roomtype_selection + "'" + " , " + "'" + rec7.getTotal() + "'" + ", 'Paid',  " + "'" + check_name + "'" + ",(SELECT user.ID FROM user WHERE user.F_name = " + "'" + l.Logginname() + "'" + " ), 3," + "'" + din   + "',"+ "'" +  dout  + "',"+ "'" +  gn  + "'" + ") ;");
                        create.executeUpdate();
                    }catch(Exception e) { System.out.println(e);}
                    finally {
                        System.out.println("Function complete");
                    };
                    Card card7 = new Card(sr3.getprice(),0.3,"Yes",rec7,visa,credit,name_on_card,number_on_card,cw);
                    System.out.println(card7);
                    // print pdf
                    System.out.println(PdfReceiptCard(hotel_3.getname(),06,inv7.Booking_Date(),(0.3*sr3.getprice()),sr3.getprice(),inv7.Amount()));
                }
                //*** Hotel Balihi Bay, roomtype family room
                else if(roomtype_selection.equalsIgnoreCase(roomtypes[1]) && hotel_selection.equalsIgnoreCase(hotel_names_in_Pattaya[0])){
                    CardInterface(); //card interface method

                    // create invoice class for using function
                    Invoices inv8 = new Invoices(fr3.getprice(),0.3);
                    // create card class
                    Receipts rec8 = new Receipts(hotel_3.getname(),check_name,"room charge",06,1,fr3.getprice(),inv8.Amount(),inv8.Booking_Date());
                    try {
                        Connection con = getConnection();
                        PreparedStatement create = con.prepareStatement("INSERT INTO room (Type, Price, Status, Check_in_name, User_ID, Hotel_ID, Check_in, Check_out, Guest_NO) VALUES"
                                + " ( " + "'" + roomtype_selection + "'" + " , " + "'" + rec8.getTotal() + "'" + ", 'Paid',  " + "'" + check_name + "'" + ",(SELECT user.ID FROM user WHERE user.F_name = " + "'" + l.Logginname() + "'" + " ), 3," + "'" + din   + "',"+ "'" +  dout  + "',"+ "'" +  gn  + "'" + ") ;");
                        create.executeUpdate();
                    }catch(Exception e) { System.out.println(e);}
                    finally {
                        System.out.println("Function complete");
                    };
                    Card card8 = new Card(fr3.getprice(),0.3,"Yes",rec8,visa,credit,name_on_card,number_on_card,cw);
                    System.out.println(card8);
                    // print pdf
                    System.out.println(PdfReceiptCard(hotel_3.getname(),06,inv8.Booking_Date(),(0.3*fr3.getprice()),fr3.getprice(),inv8.Amount()));
                }
                //*** Hotel Balihi Bay, roomtype suite room
                else if(roomtype_selection.equalsIgnoreCase(roomtypes[2]) && hotel_selection.equalsIgnoreCase(hotel_names_in_Pattaya[0])){
                    CardInterface(); //card interface method

                    // create invoice class for using function
                    Invoices inv9 = new Invoices(sur3.getprice(),0.3);
                    // create card class
                    Receipts rec9 = new Receipts(hotel_3.getname(),check_name,"room charge",06,1,sur3.getprice(),inv9.Amount(),inv9.Booking_Date());
                    try {
                        Connection con = getConnection();
                        PreparedStatement create = con.prepareStatement("INSERT INTO room (Type, Price, Status, Check_in_name, User_ID, Hotel_ID, Check_in, Check_out, Guest_NO) VALUES"
                                + " ( " + "'" + roomtype_selection + "'" + " , " + "'" + rec9.getTotal() + "'" + ", 'Paid',  " + "'" + check_name + "'" + ",(SELECT user.ID FROM user WHERE user.F_name = " + "'" + l.Logginname() + "'" + " ), 3," + "'" + din   + "',"+ "'" +  dout  + "',"+ "'" +  gn  + "'" + ") ;");
                        create.executeUpdate();
                    }catch(Exception e) { System.out.println(e);}
                    finally {
                        System.out.println("Function complete");
                    };
                    Card card9 = new Card(sur3.getprice(),0.3,"Yes",rec9,visa,credit,name_on_card,number_on_card,cw);
                    System.out.println(card9);
                    // print pdf
                    System.out.println(PdfReceiptCard(hotel_3.getname(),06,inv9.Booking_Date(),(0.3*sur3.getprice()),sur3.getprice(),inv9.Amount()));
                }
                //*** Hotel View Talay, roomtype single room
                else if(roomtype_selection.equalsIgnoreCase(roomtypes[0]) && hotel_selection.equalsIgnoreCase(hotel_names_in_Pattaya[1])){
                    CardInterface(); //card interface method

                    // create invoice class for using function
                    Invoices inv10 = new Invoices(sr4.getprice(),0.3);
                    // create card class
                    Receipts rec10 = new Receipts(hotel_4.getname(),check_name,"room charge",06,1,sr4.getprice(),inv10.Amount(),inv10.Booking_Date());
                    try {
                        Connection con = getConnection();
                        PreparedStatement create = con.prepareStatement("INSERT INTO room (Type, Price, Status, Check_in_name, User_ID, Hotel_ID, Check_in, Check_out, Guest_NO) VALUES"
                                + " ( " + "'" + roomtype_selection + "'" + " , " + "'" + rec10.getTotal() + "'" + ", 'Paid',  " + "'" + check_name + "'" + ",(SELECT user.ID FROM user WHERE user.F_name = " + "'" + l.Logginname() + "'" + " ), 4," + "'" + din   + "',"+ "'" +  dout  + "',"+ "'" +  gn  + "'" + ") ;");
                        create.executeUpdate();
                    }catch(Exception e) { System.out.println(e);}
                    finally {
                        System.out.println("Function complete");
                    };
                    Card card10 = new Card(sr4.getprice(),0.3,"Yes",rec10,visa,credit,name_on_card,number_on_card,cw);
                    System.out.println(card10);
                    // print pdf
                    System.out.println(PdfReceiptCard(hotel_4.getname(),06,inv10.Booking_Date(),(0.3*sr4.getprice()),sr4.getprice(),inv10.Amount()));
                }
                //*** Hotel View Talay, roomtype family room
                else if(roomtype_selection.equalsIgnoreCase(roomtypes[1]) && hotel_selection.equalsIgnoreCase(hotel_names_in_Pattaya[1])){
                    CardInterface(); //card interface method

                    // create invoice class for using function
                    Invoices inv11 = new Invoices(fr4.getprice(),0.3);
                    // create card class
                    Receipts rec11 = new Receipts(hotel_4.getname(),check_name,"room charge",06,1,fr4.getprice(),inv11.Amount(),inv11.Booking_Date());
                    try {
                        Connection con = getConnection();
                        PreparedStatement create = con.prepareStatement("INSERT INTO room (Type, Price, Status, Check_in_name, User_ID, Hotel_ID, Check_in, Check_out, Guest_NO) VALUES"
                                + " ( " + "'" + roomtype_selection + "'" + " , " + "'" + rec11.getTotal() + "'" + ", 'Paid',  " + "'" + check_name + "'" + ",(SELECT user.ID FROM user WHERE user.F_name = " + "'" + l.Logginname() + "'" + " ), 4," + "'" + din   + "',"+ "'" +  dout  + "',"+ "'" +  gn  + "'" + ") ;");
                        create.executeUpdate();
                    }catch(Exception e) { System.out.println(e);}
                    finally {
                        System.out.println("Function complete");
                    };
                    Card card11 = new Card(fr4.getprice(),0.3,"Yes",rec11,visa,credit,name_on_card,number_on_card,cw);
                    System.out.println(card11);
                    // print pdf
                    System.out.println(PdfReceiptCard(hotel_4.getname(),06,inv11.Booking_Date(),(0.3*fr4.getprice()),fr4.getprice(),inv11.Amount()));
            }
                //*** Hotel View Talay, roomtype suite room
                else if(roomtype_selection.equalsIgnoreCase(roomtypes[2]) && hotel_selection.equalsIgnoreCase(hotel_names_in_Pattaya[1])){
                    CardInterface(); //card interface method

                    // create invoice class for using function
                    Invoices inv12 = new Invoices(sur4.getprice(),0.3);
                    // create card class
                    Receipts rec12 = new Receipts(hotel_4.getname(),check_name,"room charge",06,1,sur4.getprice(),inv12.Amount(),inv12.Booking_Date());
                    try {
                        Connection con = getConnection();
                        PreparedStatement create = con.prepareStatement("INSERT INTO room (Type, Price, Status, Check_in_name, User_ID, Hotel_ID, Check_in, Check_out, Guest_NO) VALUES"
                                + " ( " + "'" + roomtype_selection + "'" + " , " + "'" + rec12.getTotal() + "'" + ", 'Paid',  " + "'" + check_name + "'" + ",(SELECT user.ID FROM user WHERE user.F_name = " + "'" + l.Logginname() + "'" + " ), 4," + "'" + din   + "',"+ "'" +  dout  + "',"+ "'" +  gn  + "'" + ") ;");
                        create.executeUpdate();
                    }catch(Exception e) { System.out.println(e);}
                    finally {
                        System.out.println("Function complete");
                    };
                    Card card12 = new Card(sur4.getprice(),0.3,"Yes",rec12,visa,credit,name_on_card,number_on_card,cw);
                    System.out.println(card12);
                    // print pdf
                    System.out.println(PdfReceiptCard(hotel_4.getname(),06,inv12.Booking_Date(),(0.3*sur4.getprice()),sur4.getprice(),inv12.Amount()));
                }
                System.out.println("-----------------------");
                break;
            }
            // if payment = cash
            else if(payment_option.equalsIgnoreCase(payments[1])){
                //***Hotel1 Nova, roomtype single room***//
                if(roomtype_selection.equalsIgnoreCase(roomtypes[0]) && hotel_selection.equalsIgnoreCase(hotel_names_in_Bangkok[0])){
                    // interface
                    CashAndOnlineBankingInterface(); // method

                    // create invoice class for using function
                    Invoices inv1 = new Invoices(sr1.getprice(),0.3);
                    // create card class
                    Receipts rec1 = new Receipts(hotel_1.getname(),check_name,"room charge",06,1,sr1.getprice(),inv1.Amount(),inv1.Booking_Date());
                    try {
                        Connection con = getConnection();
                        PreparedStatement create = con.prepareStatement("INSERT INTO room (Type, Price, Status, Check_in_name, User_ID, Hotel_ID, Check_in, Check_out, Guest_NO) VALUES"
                                + " ( " + "'" + roomtype_selection + "'" + " , " + "'" + rec1.getTotal() + "'" + ", 'Unpaid',  " + "'" + check_name + "'" + ",(SELECT user.ID FROM user WHERE user.F_name = " + "'" + l.Logginname() + "'" + " ), 1," + "'" + din   + "',"+ "'" +  dout  + "',"+ "'" +  gn  + "'" + ") ;");
                        create.executeUpdate();
                    }catch(Exception e) { System.out.println(e);}
                    finally {
                        System.out.println("Function complete");
                    };
                    Cash cash1 = new Cash(sr1.getprice(),0.3,"Yes",rec1,"Bath");
                    System.out.println(cash1);
                    // print pdf
                    System.out.println(PdfReceiptCard(hotel_1.getname(),06,inv1.Booking_Date(),(0.3*sr1.getprice()),sr1.getprice(),inv1.Amount(),"Cash","Unpaid"));
                }
                //***Hotel Nova, roomtype family room***//
                else if(roomtype_selection.equalsIgnoreCase(roomtypes[1]) && hotel_selection.equalsIgnoreCase(hotel_names_in_Bangkok[0])){
                    // interface
                    CashAndOnlineBankingInterface(); // method

                    // create invoice class for using function
                    Invoices inv2 = new Invoices(fr1.getprice(),0.3);
                    // create card class
                    Receipts rec2 = new Receipts(hotel_1.getname(),check_name,"room charge",06,1,fr1.getprice(),inv2.Amount(),inv2.Booking_Date());
                    try {
                        Connection con = getConnection();
                        PreparedStatement create = con.prepareStatement("INSERT INTO room (Type, Price, Status, Check_in_name, User_ID, Hotel_ID, Check_in, Check_out, Guest_NO) VALUES"
                                + " ( " + "'" + roomtype_selection + "'" + " , " + "'" + rec2.getTotal() + "'" + ", 'Unpaid',  " + "'" + check_name + "'" + ",(SELECT user.ID FROM user WHERE user.F_name = " + "'" + l.Logginname() + "'" + " ), 1," + "'" + din   + "',"+ "'" +  dout  + "',"+ "'" +  gn  + "'" + ") ;");
                        create.executeUpdate();
                    }catch(Exception e) { System.out.println(e);}
                    finally {
                        System.out.println("Function complete");
                    };
                    Cash cash2 = new Cash(fr1.getprice(),0.3,"Yes",rec2,"Bath");
                    System.out.println(cash2);
                    // print pdf
                    System.out.println(PdfReceiptCard(hotel_1.getname(),06,inv2.Booking_Date(),(0.3*fr1.getprice()),fr1.getprice(),inv2.Amount(),"Cash","Unpaid"));
                }
                //***Hotel Nova, roomtype suite room***//
                else if(roomtype_selection.equalsIgnoreCase(roomtypes[2]) && hotel_selection.equalsIgnoreCase(hotel_names_in_Bangkok[0])){
                    // interface
                    CashAndOnlineBankingInterface(); // method

                    // create invoice class for using function
                    Invoices inv3 = new Invoices(sur1.getprice(),0.3);
                    // create card class
                    Receipts rec3 = new Receipts(hotel_1.getname(),check_name,"room charge",06,1,sur1.getprice(),inv3.Amount(),inv3.Booking_Date());
                    try {
                        Connection con = getConnection();
                        PreparedStatement create = con.prepareStatement("INSERT INTO room (Type, Price, Status, Check_in_name, User_ID, Hotel_ID, Check_in, Check_out, Guest_NO) VALUES"
                                + " ( " + "'" + roomtype_selection + "'" + " , " + "'" + rec3.getTotal() + "'" + ", 'Unpaid',  " + "'" + check_name + "'" + ",(SELECT user.ID FROM user WHERE user.F_name = " + "'" + l.Logginname() + "'" + " ), 1," + "'" + din   + "',"+ "'" +  dout  + "',"+ "'" +  gn  + "'" + ") ;");
                        create.executeUpdate();
                    }catch(Exception e) { System.out.println(e);}
                    finally {
                        System.out.println("Function complete");
                    };
                    Cash cash3 = new Cash(sur1.getprice(),0.3,"Yes",rec3,"Bath");
                    System.out.println(cash3);
                    // print pdf
                    System.out.println(PdfReceiptCard(hotel_1.getname(),06,inv3.Booking_Date(),(0.3*sur1.getprice()),sur1.getprice(),inv3.Amount(),"Cash","Unpaid"));
                }
                //***Hotel Iris, roomtype single room***//
                else if(roomtype_selection.equalsIgnoreCase(roomtypes[0]) && hotel_selection.equalsIgnoreCase(hotel_names_in_Bangkok[1])){
                    // interface
                    CashAndOnlineBankingInterface(); // method

                    // create invoice class for using function
                    Invoices inv4 = new Invoices(sr2.getprice(),0.3);
                    // create card class
                    Receipts rec4 = new Receipts(hotel_2.getname(),check_name,"room charge",06,1,sur1.getprice(),inv4.Amount(),inv4.Booking_Date());
                    try {
                        Connection con = getConnection();
                        PreparedStatement create = con.prepareStatement("INSERT INTO room (Type, Price, Status, Check_in_name, User_ID, Hotel_ID, Check_in, Check_out, Guest_NO) VALUES"
                                + " ( " + "'" + roomtype_selection + "'" + " , " + "'" + rec4.getTotal() + "'" + ", 'Unpaid',  " + "'" + check_name + "'" + ",(SELECT user.ID FROM user WHERE user.F_name = " + "'" + l.Logginname() + "'" + " ), 2," + "'" + din   + "',"+ "'" +  dout  + "',"+ "'" +  gn  + "'" + ") ;");
                        create.executeUpdate();
                    }catch(Exception e) { System.out.println(e);}
                    finally {
                        System.out.println("Function complete");
                    };
                    Cash cash4 = new Cash(sr2.getprice(),0.3,"Yes",rec4,"Bath");
                    System.out.println(cash4);
                    // print pdf
                    System.out.println(PdfReceiptCard(hotel_2.getname(),06,inv4.Booking_Date(),(0.3*sr2.getprice()),sr2.getprice(),inv4.Amount(),"Cash","Unpaid"));
                }
                //***Hotel Iris, roomtype family room***//
                else if(roomtype_selection.equalsIgnoreCase(roomtypes[1]) && hotel_selection.equalsIgnoreCase(hotel_names_in_Bangkok[1])){
                    // interface
                    CashAndOnlineBankingInterface(); // method

                    // create invoice class for using function
                    Invoices inv5 = new Invoices(fr2.getprice(),0.3);
                    // create card class
                    Receipts rec5 = new Receipts(hotel_2.getname(),check_name,"room charge",06,1,fr2.getprice(),inv5.Amount(),inv5.Booking_Date());
                    try {
                        Connection con = getConnection();
                        PreparedStatement create = con.prepareStatement("INSERT INTO room (Type, Price, Status, Check_in_name, User_ID, Hotel_ID, Check_in, Check_out, Guest_NO) VALUES"
                                + " ( " + "'" + roomtype_selection + "'" + " , " + "'" + rec5.getTotal() + "'" + ", 'Unpaid',  " + "'" + check_name + "'" + ",(SELECT user.ID FROM user WHERE user.F_name = " + "'" + l.Logginname() + "'" + " ), 2," + "'" + din   + "',"+ "'" +  dout  + "',"+ "'" +  gn  + "'" + ") ;");
                        create.executeUpdate();
                    }catch(Exception e) { System.out.println(e);}
                    finally {
                        System.out.println("Function complete");
                    };
                    Cash cash5 = new Cash(fr2.getprice(),0.3,"Yes",rec5,"Bath");
                    System.out.println(cash5);
                    // print pdf
                    System.out.println(PdfReceiptCard(hotel_2.getname(),06,inv5.Booking_Date(),(0.3*fr2.getprice()),fr2.getprice(),inv5.Amount(),"Cash","Unpaid"));
                }
                //***Hotel Iris, roomtype suite room***//
                else if(roomtype_selection.equalsIgnoreCase(roomtypes[2]) && hotel_selection.equalsIgnoreCase(hotel_names_in_Bangkok[1])){
                    // interface
                    CashAndOnlineBankingInterface(); // method

                    // create invoice class for using function
                    Invoices inv6 = new Invoices(sur2.getprice(),0.3);
                    // create card class
                    Receipts rec6 = new Receipts(hotel_2.getname(),check_name,"room charge",06,1,sur2.getprice(),inv6.Amount(),inv6.Booking_Date());
                    try {
                        Connection con = getConnection();
                        PreparedStatement create = con.prepareStatement("INSERT INTO room (Type, Price, Status, Check_in_name, User_ID, Hotel_ID, Check_in, Check_out, Guest_NO) VALUES"
                                + " ( " + "'" + roomtype_selection + "'" + " , " + "'" + rec6.getTotal() + "'" + ", 'Unpaid',  " + "'" + check_name + "'" + ",(SELECT user.ID FROM user WHERE user.F_name = " + "'" + l.Logginname() + "'" + " ), 2," + "'" + din   + "',"+ "'" +  dout  + "',"+ "'" +  gn  + "'" + ") ;");
                        create.executeUpdate();
                    }catch(Exception e) { System.out.println(e);}
                    finally {
                        System.out.println("Function complete");
                    };
                    Cash cash6 = new Cash(sur2.getprice(),0.3,"Yes",rec6,"Bath");
                    System.out.println(cash6);
                    // print pdf
                    System.out.println(PdfReceiptCard(hotel_2.getname(),06,inv6.Booking_Date(),(0.3*sur2.getprice()),sur2.getprice(),inv6.Amount(),"Cash","Unpaid"));
                }
                //*** Hotel Balihi Bay, roomtype single room
                else if(roomtype_selection.equalsIgnoreCase(roomtypes[0]) && hotel_selection.equalsIgnoreCase(hotel_names_in_Pattaya[0])){
                    // interface
                    CashAndOnlineBankingInterface(); // method

                    // create invoice class for using function
                    Invoices inv7 = new Invoices(sr3.getprice(),0.3);
                    // create card class
                    Receipts rec7 = new Receipts(hotel_3.getname(),check_name,"room charge",06,1,sr3.getprice(),inv7.Amount(),inv7.Booking_Date());
                    try {
                        Connection con = getConnection();
                        PreparedStatement create = con.prepareStatement("INSERT INTO room (Type, Price, Status, Check_in_name, User_ID, Hotel_ID, Check_in, Check_out, Guest_NO) VALUES"
                                + " ( " + "'" + roomtype_selection + "'" + " , " + "'" + rec7.getTotal() + "'" + ", 'Unpaid',  " + "'" + check_name + "'" + ",(SELECT user.ID FROM user WHERE user.F_name = " + "'" + l.Logginname() + "'" + " ), 3," + "'" + din   + "',"+ "'" +  dout  + "',"+ "'" +  gn  + "'" + ") ;");
                        create.executeUpdate();
                    }catch(Exception e) { System.out.println(e);}
                    finally {
                        System.out.println("Function complete");
                    };
                    Cash cash7 = new Cash(sr3.getprice(),0.3,"Yes",rec7,"Bath");
                    System.out.println(cash7);
                    // print pdf
                    System.out.println(PdfReceiptCard(hotel_3.getname(),06,inv7.Booking_Date(),(0.3*sr3.getprice()),sr3.getprice(),inv7.Amount(),"Cash","Unpaid"));
                }
                //*** Hotel Balihi Bay, roomtype family room
                else if(roomtype_selection.equalsIgnoreCase(roomtypes[1]) && hotel_selection.equalsIgnoreCase(hotel_names_in_Pattaya[0])){
                    // interface
                    CashAndOnlineBankingInterface(); // method

                    // create invoice class for using function
                    Invoices inv8 = new Invoices(fr3.getprice(),0.3);
                    // create card class
                    Receipts rec8 = new Receipts(hotel_3.getname(),check_name,"room charge",06,1,fr3.getprice(),inv8.Amount(),inv8.Booking_Date());
                    try {
                        Connection con = getConnection();
                        PreparedStatement create = con.prepareStatement("INSERT INTO room (Type, Price, Status, Check_in_name, User_ID, Hotel_ID, Check_in, Check_out, Guest_NO) VALUES"
                                + " ( " + "'" + roomtype_selection + "'" + " , " + "'" + rec8.getTotal() + "'" + ", 'Unpaid',  " + "'" + check_name + "'" + ",(SELECT user.ID FROM user WHERE user.F_name = " + "'" + l.Logginname() + "'" + " ), 3," + "'" + din   + "',"+ "'" +  dout  + "',"+ "'" +  gn  + "'" + ") ;");
                        create.executeUpdate();
                    }catch(Exception e) { System.out.println(e);}
                    finally {
                        System.out.println("Function complete");
                    };
                    Cash cash8 = new Cash(fr3.getprice(),0.3,"Yes",rec8,"Bath");
                    System.out.println(cash8);
                    // print pdf
                    System.out.println(PdfReceiptCard(hotel_3.getname(),06,inv8.Booking_Date(),(0.3*fr3.getprice()),fr3.getprice(),inv8.Amount(),"Cash","Unpaid"));
                }
                //*** Hotel Balihi Bay, roomtype suite room
                else if(roomtype_selection.equalsIgnoreCase(roomtypes[2]) && hotel_selection.equalsIgnoreCase(hotel_names_in_Pattaya[0])){
                    // interface
                    CashAndOnlineBankingInterface(); // method

                    // create invoice class for using function
                    Invoices inv9 = new Invoices(sur3.getprice(),0.3);
                    // create card class
                    Receipts rec9 = new Receipts(hotel_3.getname(),check_name,"room charge",06,1,sur3.getprice(),inv9.Amount(),inv9.Booking_Date());
                    try {
                        Connection con = getConnection();
                        PreparedStatement create = con.prepareStatement("INSERT INTO room (Type, Price, Status, Check_in_name, User_ID, Hotel_ID, Check_in, Check_out, Guest_NO) VALUES"
                                + " ( " + "'" + roomtype_selection + "'" + " , " + "'" + rec9.getTotal() + "'" + ", 'Unpaid',  " + "'" + check_name + "'" + ",(SELECT user.ID FROM user WHERE user.F_name = " + "'" + l.Logginname() + "'" + " ), 3," + "'" + din   + "',"+ "'" +  dout  + "',"+ "'" +  gn  + "'" + ") ;");
                        create.executeUpdate();
                    }catch(Exception e) { System.out.println(e);}
                    finally {
                        System.out.println("Function complete");
                    };
                    Cash cash9 = new Cash(sur3.getprice(),0.3,"Yes",rec9,"Bath");
                    System.out.println(cash9);
                    // print pdf
                    System.out.println(PdfReceiptCard(hotel_3.getname(),06,inv9.Booking_Date(),(0.3*sur3.getprice()),sur3.getprice(),inv9.Amount(),"Cash","Unpaid"));
                }
                //*** Hotel View Talay, roomtype single room
                else if(roomtype_selection.equalsIgnoreCase(roomtypes[0]) && hotel_selection.equalsIgnoreCase(hotel_names_in_Pattaya[1])){
                    // interface
                    CashAndOnlineBankingInterface(); // method

                    // create invoice class for using function
                    Invoices inv10 = new Invoices(sr4.getprice(),0.3);
                    // create card class
                    Receipts rec10 = new Receipts(hotel_4.getname(),check_name,"room charge",06,1,sr4.getprice(),inv10.Amount(),inv10.Booking_Date());
                    try {
                        Connection con = getConnection();
                        PreparedStatement create = con.prepareStatement("INSERT INTO room (Type, Price, Status, Check_in_name, User_ID, Hotel_ID, Check_in, Check_out, Guest_NO) VALUES"
                                + " ( " + "'" + roomtype_selection + "'" + " , " + "'" + rec10.getTotal() + "'" + ", 'Unpaid',  " + "'" + check_name + "'" + ",(SELECT user.ID FROM user WHERE user.F_name = " + "'" + l.Logginname() + "'" + " ), 4," + "'" + din   + "',"+ "'" +  dout  + "',"+ "'" +  gn  + "'" + ") ;");
                        create.executeUpdate();
                    }catch(Exception e) { System.out.println(e);}
                    finally {
                        System.out.println("Function complete");
                    };
                    Cash cash10 = new Cash(sr4.getprice(),0.3,"Yes",rec10,"Bath");
                    System.out.println(cash10);
                    // print pdf
                    System.out.println(PdfReceiptCard(hotel_4.getname(),06,inv10.Booking_Date(),(0.3*sr4.getprice()),sr4.getprice(),inv10.Amount(),"Cash","Unpaid"));
                }
                //*** Hotel View Talay, roomtype family room
                else if(roomtype_selection.equalsIgnoreCase(roomtypes[1]) && hotel_selection.equalsIgnoreCase(hotel_names_in_Pattaya[1])){
                    // interface
                    CashAndOnlineBankingInterface(); // method

                    // create invoice class for using function
                    Invoices inv11 = new Invoices(fr4.getprice(),0.3);
                    // create card class
                    Receipts rec11 = new Receipts(hotel_4.getname(),check_name,"room charge",06,1,fr4.getprice(),inv11.Amount(),inv11.Booking_Date());
                    try {
                        Connection con = getConnection();
                        PreparedStatement create = con.prepareStatement("INSERT INTO room (Type, Price, Status, Check_in_name, User_ID, Hotel_ID, Check_in, Check_out, Guest_NO) VALUES"
                                + " ( " + "'" + roomtype_selection + "'" + " , " + "'" + rec11.getTotal() + "'" + ", 'Unpaid',  " + "'" + check_name + "'" + ",(SELECT user.ID FROM user WHERE user.F_name = " + "'" + l.Logginname() + "'" + " ), 4," + "'" + din   + "',"+ "'" +  dout  + "',"+ "'" +  gn  + "'" + ") ;");
                        create.executeUpdate();
                    }catch(Exception e) { System.out.println(e);}
                    finally {
                        System.out.println("Function complete");
                    };
                    Cash cash11 = new Cash(fr4.getprice(),0.3,"Yes",rec11,"Bath");
                    System.out.println(cash11);
                    // print pdf
                    System.out.println(PdfReceiptCard(hotel_4.getname(),06,inv11.Booking_Date(),(0.3*fr4.getprice()),fr4.getprice(),inv11.Amount(),"Cash","Unpaid"));
                }
                //*** Hotel View Talay, roomtype suite room
                else if(roomtype_selection.equalsIgnoreCase(roomtypes[2]) && hotel_selection.equalsIgnoreCase(hotel_names_in_Pattaya[1])){
                    // interface
                    CashAndOnlineBankingInterface(); // method

                    // create invoice class for using function
                    Invoices inv12 = new Invoices(sur4.getprice(),0.3);
                    // create card class
                    Receipts rec12 = new Receipts(hotel_4.getname(),check_name,"room charge",06,1,sur4.getprice(),inv12.Amount(),inv12.Booking_Date());
                    try {
                        Connection con = getConnection();
                        PreparedStatement create = con.prepareStatement("INSERT INTO room (Type, Price, Status, Check_in_name, User_ID, Hotel_ID, Check_in, Check_out, Guest_NO) VALUES"
                                + " ( " + "'" + roomtype_selection + "'" + " , " + "'" + rec12.getTotal() + "'" + ", 'Unpaid',  " + "'" + check_name + "'" + ",(SELECT user.ID FROM user WHERE user.F_name = " + "'" + l.Logginname() + "'" + " ), 4," + "'" + din   + "',"+ "'" +  dout  + "',"+ "'" +  gn  + "'" + ") ;");
                        create.executeUpdate();
                    }catch(Exception e) { System.out.println(e);}
                    finally {
                        System.out.println("Function complete");
                    };
                    Cash cash12 = new Cash(sur4.getprice(),0.3,"Yes",rec12,"Bath");
                    System.out.println(cash12);
                    // print pdf
                    System.out.println(PdfReceiptCard(hotel_4.getname(),06,inv12.Booking_Date(),(0.3*sur4.getprice()),sur4.getprice(),inv12.Amount(),"Cash","Unpaid"));
                }
                System.out.println("-----------------------");
                break;
            }
            // if payment option = online banking
            else if(payment_option.equalsIgnoreCase(payments[2])){
                //***Hotel1 Nova, roomtype single room***//
                if(roomtype_selection.equalsIgnoreCase(roomtypes[0]) && hotel_selection.equalsIgnoreCase(hotel_names_in_Bangkok[0])){
                    // interface
                    CashAndOnlineBankingInterface(); // method

                    // create invoice class for using function
                    Invoices inv1 = new Invoices(sr1.getprice(),0.3);
                    // create card class
                    Receipts rec1 = new Receipts(hotel_1.getname(),check_name,"room charge",06,1,sr1.getprice(),inv1.Amount(),inv1.Booking_Date());
                    try {
                        Connection con = getConnection();
                        PreparedStatement create = con.prepareStatement("INSERT INTO room (Type, Price, Status, Check_in_name, User_ID, Hotel_ID, Check_in, Check_out, Guest_NO) VALUES"
                                + " ( " + "'" + roomtype_selection + "'" + " , " + "'" + rec1.getTotal() + "'" + ", 'Paid',  " + "'" + check_name + "'" + ",(SELECT user.ID FROM user WHERE user.F_name = " + "'" + l.Logginname() + "'" + " ), 1," + "'" + din   + "',"+ "'" +  dout  + "',"+ "'" +  gn  + "'" + ") ;");
                        create.executeUpdate();
                    }catch(Exception e) { System.out.println(e);}
                    finally {
                        System.out.println("Function complete");
                    };
                    Online_banking ob1 = new Online_banking(sr1.getprice(),0.3,"Yes",rec1,"Kasikorn",345678);
                    System.out.println(ob1);
                    // print pdf
                    System.out.println(PdfReceiptCard(hotel_1.getname(),06,inv1.Booking_Date(),(0.3*sr1.getprice()),sr1.getprice(),inv1.Amount(),"Online Banking","Paid"));
                }
                //***Hotel Nova, roomtype family room***//
                else if(roomtype_selection.equalsIgnoreCase(roomtypes[1]) && hotel_selection.equalsIgnoreCase(hotel_names_in_Bangkok[0])){
                    // interface
                    CashAndOnlineBankingInterface(); // method

                    // create invoice class for using function
                    Invoices inv2 = new Invoices(fr1.getprice(),0.3);
                    // create card class
                    Receipts rec2 = new Receipts(hotel_1.getname(),check_name,"room charge",06,1,fr1.getprice(),inv2.Amount(),inv2.Booking_Date());
                    try {
                        Connection con = getConnection();
                        PreparedStatement create = con.prepareStatement("INSERT INTO room (Type, Price, Status, Check_in_name, User_ID, Hotel_ID, Check_in, Check_out, Guest_NO) VALUES"
                                + " ( " + "'" + roomtype_selection + "'" + " , " + "'" + rec2.getTotal() + "'" + ", 'Paid',  " + "'" + check_name + "'" + ",(SELECT user.ID FROM user WHERE user.F_name = " + "'" + l.Logginname() + "'" + " ), 1," + "'" + din   + "',"+ "'" +  dout  + "',"+ "'" +  gn  + "'" + ") ;");
                        create.executeUpdate();
                    }catch(Exception e) { System.out.println(e);}
                    finally {
                        System.out.println("Function complete");
                    };
                    Online_banking ob2 = new Online_banking(fr1.getprice(),0.3,"Yes",rec2,"Kasikorn",345678);
                    System.out.println(ob2);
                    // print pdf
                    System.out.println(PdfReceiptCard(hotel_1.getname(),06,inv2.Booking_Date(),(0.3*fr1.getprice()),fr1.getprice(),inv2.Amount(),"Online Banking","Paid"));
                }
                //***Hotel Nova, roomtype suite room***//
                else if(roomtype_selection.equalsIgnoreCase(roomtypes[2]) && hotel_selection.equalsIgnoreCase(hotel_names_in_Bangkok[0])){
                    // interface
                    CashAndOnlineBankingInterface(); // method

                    // create invoice class for using function
                    Invoices inv3 = new Invoices(sur1.getprice(),0.3);
                    // create card class
                    Receipts rec3 = new Receipts(hotel_1.getname(),check_name,"room charge",06,1,sur1.getprice(),inv3.Amount(),inv3.Booking_Date());
                    try {
                        Connection con = getConnection();
                        PreparedStatement create = con.prepareStatement("INSERT INTO room (Type, Price, Status, Check_in_name, User_ID, Hotel_ID, Check_in, Check_out, Guest_NO) VALUES"
                                + " ( " + "'" + roomtype_selection + "'" + " , " + "'" + rec3.getTotal() + "'" + ", 'Paid',  " + "'" + check_name + "'" + ",(SELECT user.ID FROM user WHERE user.F_name = " + "'" + l.Logginname() + "'" + " ), 1," + "'" + din   + "',"+ "'" +  dout  + "',"+ "'" +  gn  + "'" + ") ;");
                        create.executeUpdate();
                    }catch(Exception e) { System.out.println(e);}
                    finally {
                        System.out.println("Function complete");
                    };
                    Online_banking ob3 = new Online_banking(sur1.getprice(),0.3,"Yes",rec3,"Kasikorn",345678);
                    System.out.println(ob3);
                    // print pdf
                    System.out.println(PdfReceiptCard(hotel_1.getname(),06,inv3.Booking_Date(),(0.3*sur1.getprice()),sur1.getprice(),inv3.Amount(),"Online Banking","Paid"));
                }
                //***Hotel Iris, roomtype single room***//
                else if(roomtype_selection.equalsIgnoreCase(roomtypes[0]) && hotel_selection.equalsIgnoreCase(hotel_names_in_Bangkok[1])){
                    // interface
                    CashAndOnlineBankingInterface(); // method

                    // create invoice class for using function
                    Invoices inv4 = new Invoices(sr2.getprice(),0.3);
                    // create card class
                    Receipts rec4 = new Receipts(hotel_2.getname(),check_name,"room charge",06,1,sur1.getprice(),inv4.Amount(),inv4.Booking_Date());
                    try {
                        Connection con = getConnection();
                        PreparedStatement create = con.prepareStatement("INSERT INTO room (Type, Price, Status, Check_in_name, User_ID, Hotel_ID, Check_in, Check_out, Guest_NO) VALUES"
                                + " ( " + "'" + roomtype_selection + "'" + " , " + "'" + rec4.getTotal() + "'" + ", 'Paid',  " + "'" + check_name + "'" + ",(SELECT user.ID FROM user WHERE user.F_name = " + "'" + l.Logginname() + "'" + " ), 2," + "'" + din   + "',"+ "'" +  dout  + "',"+ "'" +  gn  + "'" + ") ;");
                        create.executeUpdate();
                    }catch(Exception e) { System.out.println(e);}
                    finally {
                        System.out.println("Function complete");
                    };
                    Online_banking ob4 = new Online_banking(sr2.getprice(),0.3,"Yes",rec4,"Kasikorn",345678);
                    System.out.println(ob4);
                    // print pdf
                    System.out.println(PdfReceiptCard(hotel_2.getname(),06,inv4.Booking_Date(),(0.3*sr2.getprice()),sr2.getprice(),inv4.Amount(),"Online Banking","Paid"));
                }
                //***Hotel Iris, roomtype family room***//
                else if(roomtype_selection.equalsIgnoreCase(roomtypes[1]) && hotel_selection.equalsIgnoreCase(hotel_names_in_Bangkok[1])){
                    // interface
                    CashAndOnlineBankingInterface(); // method

                    // create invoice class for using function
                    Invoices inv5 = new Invoices(fr2.getprice(),0.3);
                    // create card class
                    Receipts rec5 = new Receipts(hotel_2.getname(),check_name,"room charge",06,1,fr2.getprice(),inv5.Amount(),inv5.Booking_Date());
                    try {
                        Connection con = getConnection();
                        PreparedStatement create = con.prepareStatement("INSERT INTO room (Type, Price, Status, Check_in_name, User_ID, Hotel_ID, Check_in, Check_out, Guest_NO) VALUES"
                                + " ( " + "'" + roomtype_selection + "'" + " , " + "'" + rec5.getTotal() + "'" + ", 'Paid',  " + "'" + check_name + "'" + ",(SELECT user.ID FROM user WHERE user.F_name = " + "'" + l.Logginname() + "'" + " ), 2," + "'" + din   + "',"+ "'" +  dout  + "',"+ "'" +  gn  + "'" + ") ;");
                        create.executeUpdate();
                    }catch(Exception e) { System.out.println(e);}
                    finally {
                        System.out.println("Function complete");
                    };
                    Online_banking ob5 = new Online_banking(fr2.getprice(),0.3,"Yes",rec5,"Kasikorn",345678);
                    System.out.println(ob5);
                    // print pdf
                    System.out.println(PdfReceiptCard(hotel_2.getname(),06,inv5.Booking_Date(),(0.3*fr2.getprice()),fr2.getprice(),inv5.Amount(),"Online Banking","Paid"));
                }
                //***Hotel Iris, roomtype suite room***//
                else if(roomtype_selection.equalsIgnoreCase(roomtypes[2]) && hotel_selection.equalsIgnoreCase(hotel_names_in_Bangkok[1])){
                    // interface
                    CashAndOnlineBankingInterface(); // method

                    // create invoice class for using function
                    Invoices inv6 = new Invoices(sur2.getprice(),0.3);
                    // create card class
                    Receipts rec6 = new Receipts(hotel_2.getname(),check_name,"room charge",06,1,sur2.getprice(),inv6.Amount(),inv6.Booking_Date());
                    try {
                        Connection con = getConnection();
                        PreparedStatement create = con.prepareStatement("INSERT INTO room (Type, Price, Status, Check_in_name, User_ID, Hotel_ID, Check_in, Check_out, Guest_NO) VALUES"
                                + " ( " + "'" + roomtype_selection + "'" + " , " + "'" + rec6.getTotal() + "'" + ", 'Paid',  " + "'" + check_name + "'" + ",(SELECT user.ID FROM user WHERE user.F_name = " + "'" + l.Logginname() + "'" + " ), 2," + "'" + din   + "',"+ "'" +  dout  + "',"+ "'" +  gn  + "'" + ") ;");
                        create.executeUpdate();
                    }catch(Exception e) { System.out.println(e);}
                    finally {
                        System.out.println("Function complete");
                    };
                    Online_banking ob6 = new Online_banking(sur2.getprice(),0.3,"Yes",rec6,"Kasikorn",345678);
                    System.out.println(ob6);
                    // print pdf
                    System.out.println(PdfReceiptCard(hotel_2.getname(),06,inv6.Booking_Date(),(0.3*sur2.getprice()),sur2.getprice(),inv6.Amount(),"Online Banking","Paid"));
                }
                //*** Hotel Balihi Bay, roomtype single room
                else if(roomtype_selection.equalsIgnoreCase(roomtypes[0]) && hotel_selection.equalsIgnoreCase(hotel_names_in_Pattaya[0])){
                    // interface
                    CashAndOnlineBankingInterface(); // method

                    // create invoice class for using function
                    Invoices inv7 = new Invoices(sr3.getprice(),0.3);
                    // create card class
                    Receipts rec7 = new Receipts(hotel_3.getname(),check_name,"room charge",06,1,sr3.getprice(),inv7.Amount(),inv7.Booking_Date());
                    try {
                        Connection con = getConnection();
                        PreparedStatement create = con.prepareStatement("INSERT INTO room (Type, Price, Status, Check_in_name, User_ID, Hotel_ID, Check_in, Check_out, Guest_NO) VALUES"
                                + " ( " + "'" + roomtype_selection + "'" + " , " + "'" + rec7.getTotal() + "'" + ", 'Paid',  " + "'" + check_name + "'" + ",(SELECT user.ID FROM user WHERE user.F_name = " + "'" + l.Logginname() + "'" + " ), 3," + "'" + din   + "',"+ "'" +  dout  + "',"+ "'" +  gn  + "'" + ") ;");
                        create.executeUpdate();
                    }catch(Exception e) { System.out.println(e);}
                    finally {
                        System.out.println("Function complete");
                    };
                    Online_banking ob7 = new Online_banking(sr3.getprice(),0.3,"Yes",rec7,"Kasikorn",345678);
                    System.out.println(ob7);
                    // print pdf
                    System.out.println(PdfReceiptCard(hotel_3.getname(),06,inv7.Booking_Date(),(0.3*sr3.getprice()),sr3.getprice(),inv7.Amount(),"Online Banking","Paid"));
                }
                //*** Hotel Balihi Bay, roomtype family room
                else if(roomtype_selection.equalsIgnoreCase(roomtypes[1]) && hotel_selection.equalsIgnoreCase(hotel_names_in_Pattaya[0])){
                    // interface
                    CashAndOnlineBankingInterface(); // method

                    // create invoice class for using function
                    Invoices inv8 = new Invoices(fr3.getprice(),0.3);
                    // create card class
                    Receipts rec8 = new Receipts(hotel_3.getname(),check_name,"room charge",06,1,fr3.getprice(),inv8.Amount(),inv8.Booking_Date());
                    try {
                        Connection con = getConnection();
                        PreparedStatement create = con.prepareStatement("INSERT INTO room (Type, Price, Status, Check_in_name, User_ID, Hotel_ID, Check_in, Check_out, Guest_NO) VALUES"
                                + " ( " + "'" + roomtype_selection + "'" + " , " + "'" + rec8.getTotal() + "'" + ", 'Paid',  " + "'" + check_name + "'" + ",(SELECT user.ID FROM user WHERE user.F_name = " + "'" + l.Logginname() + "'" + " ), 3," + "'" + din   + "',"+ "'" +  dout  + "',"+ "'" +  gn  + "'" + ") ;");
                        create.executeUpdate();
                    }catch(Exception e) { System.out.println(e);}
                    finally {
                        System.out.println("Function complete");
                    };
                    Online_banking ob8 = new Online_banking(fr3.getprice(),0.3,"Yes",rec8,"Kasikorn",345678);
                    System.out.println(ob8);
                    // print pdf
                    System.out.println(PdfReceiptCard(hotel_3.getname(),06,inv8.Booking_Date(),(0.3*fr3.getprice()),fr3.getprice(),inv8.Amount(),"Online Banking","Paid"));
                }
                //*** Hotel Balihi Bay, roomtype suite room
                else if(roomtype_selection.equalsIgnoreCase(roomtypes[2]) && hotel_selection.equalsIgnoreCase(hotel_names_in_Pattaya[0])){
                    // interface
                    CashAndOnlineBankingInterface(); // method

                    // create invoice class for using function
                    Invoices inv9 = new Invoices(sur3.getprice(),0.3);
                    // create card class
                    Receipts rec9 = new Receipts(hotel_3.getname(),check_name,"room charge",06,1,sur3.getprice(),inv9.Amount(),inv9.Booking_Date());
                    try {
                        Connection con = getConnection();
                        PreparedStatement create = con.prepareStatement("INSERT INTO room (Type, Price, Status, Check_in_name, User_ID, Hotel_ID, Check_in, Check_out, Guest_NO) VALUES"
                                + " ( " + "'" + roomtype_selection + "'" + " , " + "'" + rec9.getTotal() + "'" + ", 'Paid',  " + "'" + check_name + "'" + ",(SELECT user.ID FROM user WHERE user.F_name = " + "'" + l.Logginname() + "'" + " ), 3," + "'" + din   + "',"+ "'" +  dout  + "',"+ "'" +  gn  + "'" + ") ;");
                        create.executeUpdate();
                    }catch(Exception e) { System.out.println(e);}
                    finally {
                        System.out.println("Function complete");
                    };
                    Online_banking ob9 = new Online_banking(sur3.getprice(),0.3,"Yes",rec9,"Kasikorn",345678);
                    System.out.println(ob9);
                    // print pdf
                    System.out.println(PdfReceiptCard(hotel_3.getname(),06,inv9.Booking_Date(),(0.3*sur3.getprice()),sur3.getprice(),inv9.Amount(),"Online Banking","Paid"));
                }
                //*** Hotel View Talay, roomtype single room
                else if(roomtype_selection.equalsIgnoreCase(roomtypes[0]) && hotel_selection.equalsIgnoreCase(hotel_names_in_Pattaya[1])){
                    // interface
                    CashAndOnlineBankingInterface(); // method

                    // create invoice class for using function
                    Invoices inv10 = new Invoices(sr4.getprice(),0.3);
                    // create card class
                    Receipts rec10 = new Receipts(hotel_4.getname(),check_name,"room charge",06,1,sr4.getprice(),inv10.Amount(),inv10.Booking_Date());
                    try {
                        Connection con = getConnection();
                        PreparedStatement create = con.prepareStatement("INSERT INTO room (Type, Price, Status, Check_in_name, User_ID, Hotel_ID, Check_in, Check_out, Guest_NO) VALUES"
                                + " ( " + "'" + roomtype_selection + "'" + " , " + "'" + rec10.getTotal() + "'" + ", 'Paid',  " + "'" + check_name + "'" + ",(SELECT user.ID FROM user WHERE user.F_name = " + "'" + l.Logginname() + "'" + " ), 4," + "'" + din   + "',"+ "'" +  dout  + "',"+ "'" +  gn  + "'" + ") ;");
                        create.executeUpdate();
                    }catch(Exception e) { System.out.println(e);}
                    finally {
                        System.out.println("Function complete");
                    };
                    Online_banking ob10 = new Online_banking(sr4.getprice(),0.3,"Yes",rec10,"Kasikorn",345678);
                    System.out.println(ob10);
                    // print pdf
                    System.out.println(PdfReceiptCard(hotel_4.getname(),06,inv10.Booking_Date(),(0.3*sr4.getprice()),sr4.getprice(),inv10.Amount(),"Online Banking","Paid"));
                }
                //*** Hotel View Talay, roomtype family room
                else if(roomtype_selection.equalsIgnoreCase(roomtypes[1]) && hotel_selection.equalsIgnoreCase(hotel_names_in_Pattaya[1])){
                    // interface
                    CashAndOnlineBankingInterface(); // method

                    // create invoice class for using function
                    Invoices inv11 = new Invoices(fr4.getprice(),0.3);
                    // create card class
                    Receipts rec11 = new Receipts(hotel_4.getname(),check_name,"room charge",06,1,fr4.getprice(),inv11.Amount(),inv11.Booking_Date());
                    try {
                        Connection con = getConnection();
                        PreparedStatement create = con.prepareStatement("INSERT INTO room (Type, Price, Status, Check_in_name, User_ID, Hotel_ID, Check_in, Check_out, Guest_NO) VALUES"
                                + " ( " + "'" + roomtype_selection + "'" + " , " + "'" + rec11.getTotal() + "'" + ", 'Paid',  " + "'" + check_name + "'" + ",(SELECT user.ID FROM user WHERE user.F_name = " + "'" + l.Logginname() + "'" + " ), 4," + "'" + din   + "',"+ "'" +  dout  + "',"+ "'" +  gn  + "'" + ") ;");
                        create.executeUpdate();
                    }catch(Exception e) { System.out.println(e);}
                    finally {
                        System.out.println("Function complete");
                    };
                    Online_banking ob11 = new Online_banking(fr4.getprice(),0.3,"Yes",rec11,"Kasikorn",345678);
                    System.out.println(ob11);
                    // print pdf
                    System.out.println(PdfReceiptCard(hotel_4.getname(),06,inv11.Booking_Date(),(0.3*fr4.getprice()),fr4.getprice(),inv11.Amount(),"Online Banking","Paid"));
                }
                //*** Hotel View Talay, roomtype suite room
                else if(roomtype_selection.equalsIgnoreCase(roomtypes[2]) && hotel_selection.equalsIgnoreCase(hotel_names_in_Pattaya[1])){
                    // interface
                    CashAndOnlineBankingInterface(); // method

                    // create invoice class for using function
                    Invoices inv12 = new Invoices(sur4.getprice(),0.3);
                    // create card class
                    Receipts rec12 = new Receipts(hotel_4.getname(),check_name,"room charge",06,1,sur4.getprice(),inv12.Amount(),inv12.Booking_Date());
                    try {
                        Connection con = getConnection();
                        PreparedStatement create = con.prepareStatement("INSERT INTO room (Type, Price, Status, Check_in_name, User_ID, Hotel_ID, Check_in, Check_out, Guest_NO) VALUES"
                                + " ( " + "'" + roomtype_selection + "'" + " , " + "'" + rec12.getTotal() + "'" + ", 'Paid',  " + "'" + check_name + "'" + ",(SELECT user.ID FROM user WHERE user.F_name = " + "'" + l.Logginname() + "'" + " ), 4," + "'" + din   + "',"+ "'" +  dout  + "',"+ "'" +  gn  + "'" + ") ;");
                        create.executeUpdate();
                    }catch(Exception e) { System.out.println(e);}
                    finally {
                        System.out.println("Function complete");
                    };
                    Online_banking ob12 = new Online_banking(sur4.getprice(),0.3,"Yes",rec12,"Kasikorn",345678);
                    System.out.println(ob12);
                    // print pdf
                    System.out.println(PdfReceiptCard(hotel_4.getname(),06,inv12.Booking_Date(),(0.3*sur4.getprice()),sur4.getprice(),inv12.Amount(),"Online Banking","Paid"));
                }
                System.out.println("-----------------------");
                break;
            }
            else if(payment_option.equalsIgnoreCase("P")){
                LocationSelection();
                Hotelselection();
                RoomtypeSelection();
                ChooseHotel();
                BookingConfirm();
            }
            else if(payment_option.equalsIgnoreCase("Q")){
                System.exit(0);
            }
            else{
                System.out.println("Please select the correct payment option.");
            }
        }
    }
    // card interface use in payment option
    public static void CardInterface(){
        // interface
        // user name
        System.out.print("Enter Check-in name: "); // user name input
        check_name = in.nextLine();
        // visa
        String visa_error = "0";

        while(visa_error.equals("0")) {
            System.out.print("Is it visa card? Type (Y)es/(N)o: ");
            visa = in.nextLine();
            if (visa.equalsIgnoreCase("Yes") || visa.equalsIgnoreCase("Y")) {
                visa = "Yes";
                break;
            } else if(visa.equalsIgnoreCase("No") || visa.equalsIgnoreCase("N")) {
                visa = "No";
                break;
            }
            else{

            }
        }
        // credit card
        String credit_error = "0";

        while(credit_error.equals("0")) {
            System.out.print("Is it credfit card? Type (Y)es/(N)o: ");
            credit = in.nextLine();
            if (credit.equalsIgnoreCase("Yes") || credit.equalsIgnoreCase("Y")) {
                credit = "Yes";
                break;
            } else if(credit.equalsIgnoreCase("No") || credit.equalsIgnoreCase("N")) {
                credit = "No";
                break;
            }
            else{

            }
        }
        // Name on card
        System.out.print("Enter name on card: ");
        name_on_card = in.nextLine();
        // Number on card
        System.out.print("Enter number on card: ");
        number_on_card = in.nextInt();
        // CW
        System.out.print("Enter CW: ");
        cw = in.nextInt();
        in.nextLine();
        System.out.println("-----------------------");
    }
    // cash and online Banking interface use in payment option
    public static void CashAndOnlineBankingInterface(){
        // interface
        // user name
        System.out.print("Enter Check-in name: "); // user name input
        check_name = in.nextLine();
    }

    // PDF Receipt for Card
    public static Document PdfReceiptCard(String hotelName, int invoiceNum, String date, double serviceFee, double priceAmount, double priceTotal){
        try {
            // create file
            document = new Document();
            PdfWriter writer = PdfWriter.getInstance(document, new FileOutputStream("Receipt.pdf"));
            // open the file
            document.open();

            // create Font
            Font f1 = new Font(Font.FontFamily.TIMES_ROMAN,14,Font.BOLD);
            Font f2 = new Font(Font.FontFamily.TIMES_ROMAN,10,Font.BOLD);
            Font f3 = new Font(Font.FontFamily.TIMES_ROMAN,12,Font.BOLD);
            Font fUnderline1 = new Font(Font.FontFamily.COURIER,20);
            Font fUnderline2 = new Font(Font.FontFamily.HELVETICA,20);

            // create Paragraph
            Paragraph p1 = new Paragraph(" Receipt",f1);
            Paragraph p2 = new Paragraph("Username: " + check_name +"                                                                                                                                         Hotel name: " + hotelName,f2);
            Paragraph p3 = new Paragraph("Payment: Card                                                                                                                                            Invoice No: " + invoiceNum,f2);
            Paragraph p4 = new Paragraph("Visa: " + visa,f2);
            Paragraph p5 = new Paragraph("Credit: " + credit,f2);
            Paragraph p6 = new Paragraph("Name on Card: " + name_on_card,f2);
            Paragraph p7 = new Paragraph("Number on Card: "+ number_on_card,f2);
            Paragraph p70 = new Paragraph("CW: " + cw,f2);
            Paragraph p71 = new Paragraph("Status: Paid",f2);
            Paragraph p8 = new Paragraph("Billing Instruction: ",f3);
            Paragraph p9 = new Paragraph("-------------------------------------------",fUnderline1);
            Paragraph p10 = new Paragraph("Date               Description               Quantity               Service fee               Amount               Total",f3);
            /* */Paragraph p11 = new Paragraph(date+"         Room charges                         1                         "+ serviceFee + " bath(30%)            " + priceAmount + " bath               " + priceTotal + " bath",f2);
            Paragraph p12 = new Paragraph("_______________________________________________",fUnderline2);

            // Alignment changing
            p1.setAlignment(Element.ALIGN_CENTER);

            // Add the paragraph to the document
            document.add(p1);
            document.add( Chunk.NEWLINE ); // add space between the line
            document.add(p2);
            document.add(p3);
            document.add(p4);
            document.add(p5);
            document.add(p6);
            document.add(p7);
            document.add(p70);
            document.add(p71);
            document.add(p8);
            document.add(p9);
            document.add(p10);
            document.add(p9);
            document.add(p11);
            document.add( Chunk.NEWLINE ); // add space between the line
            document.add( Chunk.NEWLINE ); // add space between the line
            document.add( Chunk.NEWLINE ); // add space between the line
            document.add( Chunk.NEWLINE ); // add space between the line
            document.add( Chunk.NEWLINE ); // add space between the line
            document.add( Chunk.NEWLINE ); // add space between the line
            document.add( Chunk.NEWLINE ); // add space between the line
            document.add( Chunk.NEWLINE ); // add space between the line
            document.add( Chunk.NEWLINE ); // add space between the line
            document.add(p12);

            // close the file
            document.close();
            writer.close();
        } catch (DocumentException e) {
            e.printStackTrace();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        return document;
    }

    // PDF Receipt for Cash and Online banking
    public static Document PdfReceiptCard(String hotelName, int invoiceNum, String date, double serviceFee, double priceAmount, double priceTotal,String payment,String status){
        try {
            // create file
            document = new Document();
            PdfWriter writer = PdfWriter.getInstance(document, new FileOutputStream("Receipt.pdf"));
            // open the file
            document.open();

            // create Font
            Font f1 = new Font(Font.FontFamily.TIMES_ROMAN,14,Font.BOLD);
            Font f2 = new Font(Font.FontFamily.TIMES_ROMAN,10,Font.BOLD);
            Font f3 = new Font(Font.FontFamily.TIMES_ROMAN,12,Font.BOLD);
            Font fUnderline1 = new Font(Font.FontFamily.COURIER,20);
            Font fUnderline2 = new Font(Font.FontFamily.HELVETICA,20);

            // create Paragraph
            Paragraph p1 = new Paragraph(" Receipt",f1);
            Paragraph p2 = new Paragraph("Username: " + check_name +"                                                                                                                                         Hotel name: " + hotelName,f2);
            Paragraph p3 = new Paragraph("Payment: " + payment + "                                                                                                                             Invoice No: " + invoiceNum,f2);
            Paragraph p71 = new Paragraph("Status: " + status,f2);
            Paragraph p8 = new Paragraph("Billing Instruction: ",f3);
            Paragraph p9 = new Paragraph("-------------------------------------------",fUnderline1);
            Paragraph p10 = new Paragraph("Date               Description               Quantity               Service fee               Amount               Total",f3);
            /* */Paragraph p11 = new Paragraph(date+"         Room charges                         1                         "+ serviceFee + " bath(30%)            " + priceAmount + " bath               " + priceTotal + " bath",f2);
            Paragraph p12 = new Paragraph("_______________________________________________",fUnderline2);

            // Alignment changing
            p1.setAlignment(Element.ALIGN_CENTER);

            // Add the paragraph to the document
            document.add(p1);
            document.add( Chunk.NEWLINE ); // add space between the line
            document.add(p2);
            document.add(p3);
            document.add(p71);
            document.add(p8);
            document.add(p9);
            document.add(p10);
            document.add(p9);
            document.add(p11);
            document.add( Chunk.NEWLINE ); // add space between the line
            document.add( Chunk.NEWLINE ); // add space between the line
            document.add( Chunk.NEWLINE ); // add space between the line
            document.add( Chunk.NEWLINE ); // add space between the line
            document.add( Chunk.NEWLINE ); // add space between the line
            document.add( Chunk.NEWLINE ); // add space between the line
            document.add( Chunk.NEWLINE ); // add space between the line
            document.add( Chunk.NEWLINE ); // add space between the line
            document.add( Chunk.NEWLINE ); // add space between the line
            document.add(p12);

            // close the file
            document.close();
            writer.close();
        } catch (DocumentException e) {
            e.printStackTrace();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        return document;
    }

    // main methodd
    public static void main(String[] args) throws Exception {
        System.out.println("-------------------------------");
        System.out.println(" Welcome to SIAM Hotel Booking");
        System.out.println("-------------------------------");
        Scanner sc = new Scanner(System.in);
        String login_loop = "0";
        while(login_loop.equals("0")) {
        System.out.print("Press L(Login), R (Sign up), E(exit): ");
        String ll = sc.nextLine();
            System.out.println("----------------------");
            if (ll.equalsIgnoreCase("L")) { //Login GUI
                LOGGIN l = new LOGGIN();
                l.loggin();
                break;
            } else if (ll.equalsIgnoreCase("R")) {
                User u = new User(); //User Sign up
                u.DBMSuser();

            }
            else if(ll.equalsIgnoreCase("E")){
                System.exit(0);
                break;
            }
            else {
                System.out.println("Insert the right key to acceess");
            }
        }

    }
    public static Connection getConnection() throws Exception{
        try {
            String driver = "com.mysql.jdbc.Driver";
            String url = "jdbc:mysql://127.0.0.1:3306/siam_booking?autoReconnect=true&useSSL=false";
            String username = "root";
            String password = "root";
            Class.forName(driver);

            Connection Conn = DriverManager.getConnection(url,username,password);
            System.out.println("Connected");
            return Conn;
        } catch(Exception e) {
            System.out.println(e);
        }
        return null;
    }
}