//package Hotels;
//import Facilities.Swimming_pools;
//import Interfaces.Address_line;
//import Interfaces.City;
//import Interfaces.Country;
//import Facilities.Canteen;
//import Facilities.Gyms;
//import Facilities.Spa;
//import java.util.Scanner;


//public class Hotel implements City, Country, Address_line{ // super class hotel
//    protected String name; // private variables
//    protected Swimming_pools swp; // composite swimming pool
//    protected Gyms g;// composite gyms
//    protected Spa sp;// composite spa
//    protected Canteen c;// composite canteen
//
//    public Hotel(){ // default
//        this.name = "default";
//    }
//
//    public Hotel(String name,Swimming_pools swp, Gyms g, Spa sp, Canteen c){ // value
//        this.name = name;
//        this.swp = swp; // swimming pool
//        this.g = g; // gyms
//        this.sp = sp; // spa
//        this.c = c; // canteen
//    }
//
//    //get
//    public String getname(){
//        return this.name;
//    }
//
//    public Swimming_pools getSwp(){
//        return this.swp;
//    }
//
//    public Gyms getG(){
//        return this.g;
//    }
//
//    public Spa getSp(){
//        return this.sp;
//    }
//
//    public Canteen getC(){
//        return this.c;
//    }
//
//    //set
//    public void setname(String name){
//        this.name = name;
//    }
//
//    public void setSwp(Swimming_pools swp){
//        this.swp = swp;
//    }
//
//    public void setG(Gyms g){
//        this.g = g;
//    }
//
//    public void setSp(Spa sp){
//        this.sp = sp;
//    }
//
//    public void setC(Canteen c){
//        this.c = c;
//    }
//
//    // String
//    public String toString(){
//        return "Hotel name: " + this.name + "\nSwimming pool: " + "\n\tAdult size: " + this.swp.adult_size + "\n\tKid size: " +
//                this.swp.kid_size + "\nGym: " +"\n\tdumbell: " + this.g.dumbell + "\n\tRunning machine: " +
//                this.g.dumbell + "\n\tWeighing scale: " + this.g.weigthing_scale + "\n\tBike machine: " +
//                this.g.bike_machine + "\nSpa: " + "\n\tFace spa: " + this.sp.face_spa + "\n\tBody spa: " +
//                this.sp.body_spa + "\nCanteen: " + "\n\tPrice per person: " + this.c.price_per_person + "\n";
//    }
//
//    @Override
//    public void City(String city) {
//        // TODO Auto-generated method stub
//        System.out.println("City: " + city);
//
//    }
//
//    @Override
//    public void Address_line(String address_line1,String address_line2) {
//        // TODO Auto-generated method stub
//
//        System.out.println("Address Line 1: " + address_line1 + "\nAddress Line 2: " + address_line2);
//    }
//
//    @Override
//    public void Country(String country) {
//        // TODO Auto-generated method stub
//
//        System.out.println("Country: " + country);
//
//    }
//}

package Hotels;
import Facilities.Swimming_pools;
import Interfaces.Get_address_line;
import Interfaces.Get_city;
import Interfaces.Get_country;
import Facilities.Canteens;
import Facilities.Gyms;
import Facilities.Spas;
public class Hotels implements Get_city, Get_country, Get_address_line { // super class hotel
    protected String name; // private variables
    protected Swimming_pools swp; // composite swimming pool
    protected Gyms g;// composite gyms
    protected Spas sp;// composite spa
    protected Canteens c;// composite canteen

    public Hotels(String name){ // default
        this.name = name;
        this.swp = new Swimming_pools();
        this.g = new Gyms();
        this.sp = new Spas();
        this.c = new Canteens();
    }


    public Hotels(String name, Swimming_pools swp, Gyms g, Spas sp, Canteens c){ // value
        this.name = name;
        this.swp = swp; // swimming pool
        this.g = g; // gyms
        this.sp = sp; // spa
        this.c = c; // canteen
    }



    // String
    public String toString(){
        return "FACILITIES\nHotel name: " + this.name + "\nSwimming pool: " + "\n\tAdult size: " + this.swp.adult_size + "\n\tKid size: " +
                this.swp.kid_size + "\nGym: " +"\n\tdumbell: " + this.g.dumbell + "\n\tRunning machine: " +
                this.g.dumbell + "\n\tWeighing scale: " + this.g.weigthing_scale + "\n\tBike machine: " +
                this.g.bike_machine + "\nSpa: " + "\n\tFace spa: " + this.sp.face_spa + "\n\tBody spa: " +
                this.sp.body_spa + "\nCanteen: " + "\n\tPrice per person: " + this.c.price_per_person + "\n";
    }


    @Override
    public String Get_city(String city) {
        // TODO Auto-generated method stub

        return "City: " + city;
    }

    @Override
    public String Get_address_line(String address_line1) {
        // TODO Auto-generated method stub

        return "Address Line 1: " + address_line1;
    }

    @Override
    public String Get_country(String country) {
        // TODO Auto-generated method stub
    return "Country: " + country;
    }

    //get
    public String getname(){
        return this.name;
    }

    public Swimming_pools getSwp(){
        return this.swp;
    }

    public Gyms getG(){
        return this.g;
    }

    public Spas getSp(){
        return this.sp;
    }

    public Canteens getC(){
        return this.c;
    }

    //set
    public void setname(String name){
        this.name = name;
    }

    public void setSwp(Swimming_pools swp){
        this.swp = swp;
    }

    public void setG(Gyms g){
        this.g = g;
    }

    public void setSp(Spas sp){
        this.sp = sp;
    }

    public void setC(Canteens c){
        this.c = c;
    }



}
