package Loggin;



import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

//import com.mysql.jdbc.PreparedStatement;

import MAIN.Program_running;


import javax.swing.JPasswordField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.*;
import java.util.Scanner;
import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.Color;

public class LOGGIN {

    public JFrame frame;
    public JTextField Username;
    public JPasswordField Password;
    static int id;
    String F_name;

    /**
     * Launch the application.
     */
    public void loggin() {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    LOGGIN window = new LOGGIN();
                    window.frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    /**
     * Create the application.
     */
    public LOGGIN() {
        initialize();
    }

    /**
     * Initialize the contents of the frame.
     */
    private void initialize() {
        frame = new JFrame();
        frame.getContentPane().setBackground(Color.GRAY);
        frame.setBounds(100, 100, 450, 300);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.getContentPane().setLayout(null);

        JLabel lblNewLabel = new JLabel("Username:");
        lblNewLabel.setBounds(34, 50, 85, 16);
        frame.getContentPane().add(lblNewLabel);

        JLabel lblNewLabel_1 = new JLabel("Password:");
        lblNewLabel_1.setBounds(34, 108, 67, 16);
        frame.getContentPane().add(lblNewLabel_1);

        Username = new JTextField();
        Username.setBounds(169, 47, 116, 22);
        frame.getContentPane().add(Username);
        Username.setColumns(10);

        Password = new JPasswordField();
        Password.setBounds(169, 105, 116, 22);
        frame.getContentPane().add(Password);

        JButton Sign_in = new JButton("Sign_in"); //Loggin
        Sign_in.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent arg0) {
                try {
                    Connection con = getConnection();
                    String sql = "Select * from loggin where Username = ? and Password = ?";
                    PreparedStatement pst = (PreparedStatement) con.prepareStatement(sql);
                    pst.setString(1, Username.getText());
                    pst.setString(2, Password.getText());
                    ResultSet rs  = pst.executeQuery();
                    if(rs.next()) {
                        JOptionPane.showMessageDialog(null, "Username and Password is Correct");
                        id = rs.getInt("User_ID");
                        //Username
                        System.out.println("WELCOME MR: " + Logginname());
                        Scanner sc = new Scanner(System.in);

                        //room cancel
                        System.out.println("B (Contninue to book the room), C (Cancle previous bookng), H (View the booking hostory) :");
                        String bc = sc.nextLine();
                        if(bc.equalsIgnoreCase("C")) {
                            try {

                                PreparedStatement create = (PreparedStatement) con.prepareStatement("DELETE FROM room WHERE User_ID =" + id + ";");
                                create.executeUpdate();
                            }catch(Exception e) { System.out.println(e);}
                            finally {
                                System.out.print("Your Booking have been cancel");
                                System.exit(0);
                            };
                        }else if(bc.equalsIgnoreCase("B")) {
                            Program_running.Meth();
                        }else if(bc.equalsIgnoreCase("H")) {
                            History();
                        }
                        //run main
                        Program_running.Meth();





                    }else {
                        JOptionPane.showMessageDialog(null, "Username and Password are Incorrect");
                        Username.setText("");
                        Password.setText("");

                    }
                    con.close();
                }catch(Exception e) {
                    JOptionPane.showMessageDialog(null, e);
                }

            }
        });
        Sign_in.setBounds(169, 172, 116, 25);
        frame.getContentPane().add(Sign_in);
    }
    public String Logginname() throws Exception {///////////////////////////////////


        try {
            Connection con = getConnection();
            Statement stmt = con.createStatement();

            ResultSet rs = stmt.executeQuery("SELECT F_name FROM user INNER JOIN loggin ON user.ID = loggin.User_ID WHERE loggin.User_ID =" + id + ";");
            while(rs.next()) {
                F_name = rs.getString("F_name");
                System.out.println( F_name);
            }
        }catch(Exception e) { System.out.println(e);}
        finally {
            System.out.println("Function complete");
        };
        return F_name;



    }
    //Booking History
    public void History()  throws Exception {
        try {
            Connection con = getConnection();
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT Check_in_name, Check_in, Check_out, Guest_NO, Type, Price, Status, Name FROM room INNER JOIN hotel ON room.User_ID = hotel.ID WHERE User_ID =" + id + ";");

            while (rs.next()) {
                String Check_name = rs.getString("Check_in_name");
                String Check_in = rs.getString("Check_in");
                String Check_out = rs.getString("Check_out");
                int Guest_NO = rs.getInt("Guest_NO");
                String Type = rs.getString("Type");
                int Price = rs.getInt("Price");
                String Status = rs.getString("Status");
                String Name = rs.getString("Name");


                System.out.println("Hotel name: " + Name
                        + "||Check in name: " + Check_name
                        + "||Check in date: " + Check_in
                        + "||Check out date: " + Check_out
                        + "||Number of guest: " + Guest_NO
                        + "||Room Type: " + Type
                        + "||Price: " + Price
                        + "||Status: " + Status);
            }
        }
        catch (Exception exc) {
            exc.printStackTrace();
        }
    }




    public Connection getConnection() throws Exception{
        try {
            String driver = "com.mysql.jdbc.Driver";
            String url = "jdbc:mysql://127.0.0.1:3306/siam_booking?autoReconnect=true&useSSL=false";
            String username = "root";
            String password = "root";
            Class.forName(driver);

            Connection Conn = DriverManager.getConnection(url,username,password);
            System.out.println("Connected");
            return Conn;
        } catch(Exception e) {
            System.out.println(e);
        }
        return null;
    }
}
