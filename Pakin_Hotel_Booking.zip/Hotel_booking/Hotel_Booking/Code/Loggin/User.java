package Loggin;

import java.sql.Connection;
import java.sql.DriverManager;
import java.time.LocalDate;
import java.util.Scanner;

//import com.mysql.jdbc.PreparedStatement;

import Interfaces.*;


public class User implements Get_city, Get_country, Get_address_line{
    private String Fname, Lname, DOB, City, Addr, Country, Password, Username;
    private int Phone_no;

    Scanner sc = new Scanner(System.in);

    public void DBMSuser() throws Exception { /////////////////////////////////////scanner


        System.out.print("First name : ");
        Fname = sc.nextLine();


        System.out.print("Last name : ");
        Lname = sc.nextLine();

        System.out.print("Date of Birth (yyyy-mm-dd) : ");
        DOB = sc.nextLine();

        System.out.print("City : ");
        City = sc.nextLine();

        System.out.print("Country : ");
        Country = sc.nextLine();

        System.out.print("Address Line : ");
        Addr = sc.nextLine();

        System.out.print("Username:  ");
        Username = sc.nextLine();

        System.out.print("Password:  ");
        Password = sc.nextLine();

        System.out.print("Phone no (10 digits): ");
        Phone_no = sc.nextInt();

        String query =  "'" + Username + "'" + "," + "'" + Password + "'";

        //////////////////////////////////////////////////////// insert into dbms
        try {
            Connection con = getConnection();
            java.sql.PreparedStatement st =  con.prepareStatement("INSERT INTO user (F_name, L_name, DOB, Phone_no, City, Country, Address_line) VALUES (?,?,?,?,?,?,?)");
            st.setString(1, Fname);
            st.setString(2, Lname);
            st.setString(3, DOB);
            st.setInt(4, Phone_no);
            st.setString(5, City);
            st.setString(6, Country);
            st.setString(7, Addr);






            st.executeUpdate();
        }catch(Exception e) { System.out.println(e);}

        ;
        try {
            Connection con = getConnection();
            java.sql.PreparedStatement lost =  con.prepareStatement("INSERT INTO loggin (Username, Password, User_ID) VALUES  (" + query + ", (SELECT ID from user WHERE F_name = " + "'"+ Fname + "'" + "));");

            lost.executeUpdate();
        }catch(Exception e) { System.out.println(e);}

        ;


    }


    public Connection getConnection() throws Exception{ //////////////////////////////get connection

        try {
            String driver = "com.mysql.jdbc.Driver";
            String url = "jdbc:mysql://127.0.0.1:3306/siam_booking?autoReconnect=true&useSSL=false";
            String username = "root";
            String password = "root";
            Class.forName(driver);

            Connection Conn = DriverManager.getConnection(url,username,password);
            System.out.println("Connected");
            return Conn;
        } catch(Exception e) {
            System.out.println(e);
        }
        return null;
    }

    public void setFname(String Fname) {
        this.Fname = Fname;
    }
    public void setLname(String Lname) {
        this.Lname = Lname;

    }
    public void setDOB(String DOB) {
        this.DOB = DOB;
    }
    public String getFname() {
        return Fname;
    }
    public String getLname() {
        return Lname;
    }
    public String DOB() {
        return DOB;
    }

    public int getPhone_no() {
        return Phone_no;
    }
    public void setPhone_no(int Phone_no) {
        this.Phone_no = Phone_no;
    }
    public String getCity() {
        return City;
    }
    public void setCity(String city) {
        this.City = city;
    }
    public String getAddr() {
        return Addr;
    }
    public void setAddr(String addr) {
        this.Addr = addr;
    }
    public String getCountry() {
        return Country;
    }
    public void setCountry(String country) {
        this.Country = country;
    }
    @Override
    public String Get_address_line(String address_line1) {


        return address_line1;
    }
    @Override
    public String Get_country(String country) {


        return country;
    }
    @Override
    public String Get_city(String city) {

        return city;
    }
}


