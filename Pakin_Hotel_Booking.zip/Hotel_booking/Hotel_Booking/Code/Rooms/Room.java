package Rooms;



public class Room { // super class room
    // variable
    protected double price,room_size;
    protected String view,bed_type,WIFI,room_cancellation,smoking,breakfast;


    // default
    public Room(){
        this.price = 0.0;
        this.room_size = 0.0;
        this.view = "default";
        this.bed_type = "default";
        this.WIFI = "No wifi is available.";
        this.room_cancellation = "No room cancellation available.";
        this.smoking = "No smoking allow in the room area.";
        this.breakfast = "No breakfast available.";
    }

    //value
    public Room(double price, double room_size, String view
            , String bed_type, String WIFI
            , String room_cancellation, String smoking, String breakfast){
        this.price = price;
        this.room_size = room_size;
        this.view = view;
        this.bed_type = bed_type;
        this.WIFI = WIFI;
        this.room_cancellation = room_cancellation;
        this.smoking = smoking;
        this.breakfast = breakfast;
    }

    // get
    public double getprice(){
        return this.price;
    }
    public String getWIFI(){
        return this.WIFI;
    }
    public String getroom_cancellation(){
        return this.room_cancellation;
    }
    public String getsmoking(){
        return this.smoking;
    }
    public String getbreakfast(){
        return this.breakfast;
    }
    public String getview(){
        return this.view;
    }
    public double getroom_size(){
        return this.room_size;
    }
    public String getbed_type(){
        return this.bed_type;
    }

    //set
    public void setprice(double price){
        this.price = price;
    }
    public void setWIFI(String WIFI){
        this.WIFI = WIFI;
    }
    public void setroom_cancellation(String room_cancellation){
        this.room_cancellation = room_cancellation;
    }
    public void setsmoking(String smoking){
        this.smoking = smoking;
    }
    public void setbreakfast(String breakfast){
        this.breakfast = breakfast;
    }
    public void setview(String view){
        this.view = view;
    }
    public void setroom_size(double room_size){
        this.room_size = room_size;
    }
    public void setbed_type(String bed_type){
        this.bed_type = bed_type;
    }

    // print
    public String toString(){
        return "Price: " + this.price + " bath\nWIFI: " + this.WIFI + "\nRoom cancellation: " +
                this.room_cancellation + "\nSmoking: " + this.smoking + "\nBreakfast: " + this.breakfast + "\nView: " +
                this.view + "\nroom_size: " + this.room_size + " inches\nBed_type: " + this.bed_type + "\n";
    }
}
