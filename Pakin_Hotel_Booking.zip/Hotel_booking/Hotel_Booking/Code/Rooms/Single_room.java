package Rooms;


public class Single_room extends Room {
    public Single_room(double price,double room_size,String view,String bed_type,String WIFI,String room_cancellation,
                       String smoking, String breakfast){
        super(price,room_size,view,bed_type,WIFI,room_cancellation,smoking,breakfast);
    }
    public String toString(){
        String str;
        str = "Single room:\n" + super.toString();
        return str;
    }
}
