package Rooms;


public class Suite extends Room { // subclass
    private String living_room,minibar;
    // inheritance from superclass
    public Suite(double price,double room_size,String view,String bed_type,String WIFI,String room_cancellation, String smoking,
                 String breakfast,String living_room,String minibar){
        super(price,room_size,view,bed_type,WIFI,room_cancellation,smoking,breakfast);
        this.living_room = living_room;
        this.minibar = minibar;
    }

    //get
    public String getLiving_room(){
        return this.living_room;
    }

    public String getMinibar(){
        return this.minibar;
    }

    //set
    public void setLiving_room(String living_room){
        this.living_room = living_room;
    }

    public void setMinibar(String minibar){
        this.minibar = minibar;
    }

    public String toString(){ // String
        String str;
        str = "Suite room:\n" + super.toString() + "\nLiving room: " + this.living_room + "\nMinibar: " + this.minibar + "\n" ;
        return str;
    }
}
