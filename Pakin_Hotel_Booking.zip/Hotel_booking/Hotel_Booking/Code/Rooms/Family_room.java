package Rooms;


public class Family_room extends Room {
    private String baby_bed;
    public Family_room(double price,double room_size,String view,String bed_type,String WIFI,String room_cancellation,
                       String smoking, String breakfast, String baby_bed){
        super(price,room_size,view,bed_type,WIFI,room_cancellation,smoking,breakfast);
        this.baby_bed = baby_bed;
    }

    //get
    public String getBaby_bed(){
        return this.baby_bed;
    }

    //set
    public void setBaby_bed(String baby_bed) {
        this.baby_bed = baby_bed;
    }

    public String toString(){ // String
        String str;
        str = "Family room:\n" + super.toString() + "Baby bed: " + this.baby_bed + "\n" ;
        return str;
    }
}
