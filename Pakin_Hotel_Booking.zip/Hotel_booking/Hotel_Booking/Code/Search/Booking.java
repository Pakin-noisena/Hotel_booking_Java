package Search;

import java.time.LocalDate;
import java.util.ArrayList;

import Interfaces.*;

public class Booking implements Get_city {
    private static final char[] City = null;
    private String Date_in,Date_out;
    private int Guest_no;


    public Booking() {

    }


    public Booking(String Date_in, String Date_out, int Guest_no) {
        this.Date_in = Date_in;
        this.Date_out = Date_out;
        this.Guest_no = Guest_no;
    }
    public String toString() {
        return "'" + Date_in + "'," + "'" + Date_out + "'," + "'" + Date_in + "'," + "'" + Guest_no + "'";
    }



    public void setGuest_no(int Guest_no) {
        this.Guest_no = Guest_no;
    }

    public int getGuest_no() {
        return Guest_no;
    }
    public void setDate_in(String Date_in) {
        this.Date_in = Date_in;
    }

    public String getDate_in() {
        return Date_in;
    }

    public void setDate_out(String Date_out) {
        this.Date_out = Date_out;
    }

    public String getDate_out() {
        return Date_out;
    }



    @Override
    public String Get_city(String city) {

        return "City: " + city;
    }
}



